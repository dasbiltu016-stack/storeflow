package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AdMobTestNativeAdCard
import com.example.ui.components.DEFAULT_TEST_NATIVE_AD_UNIT_ID
import com.example.ui.components.OfflineBackupCenterDialog
import com.example.ui.components.PinLockScreen
import com.example.ui.components.QuickCurrencySelectorDialog
import com.example.ui.components.StoreSettingsDialog
import com.example.ui.components.StoreTopAppBar
import com.example.ui.components.activeCurrencyCode
import com.example.ui.components.activeCurrencySymbol
import com.example.ui.components.shareTextReport
import com.example.ui.screens.CustomerDueScreen
import com.example.ui.screens.DashboardReportsScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.PosSalesScreen
import com.example.ui.screens.SuppliersScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ReportPeriod
import com.example.ui.viewmodel.StockFilter
import com.example.ui.viewmodel.StoreSection
import com.example.ui.viewmodel.StoreViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                StoreFlowApp()
            }
        }
    }
}

private data class NavDestination(
    val section: StoreSection,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val NAV_DESTINATIONS = listOf(
    NavDestination(
        section = StoreSection.DASHBOARD,
        label = "Reports",
        selectedIcon = Icons.Filled.Analytics,
        unselectedIcon = Icons.Outlined.Analytics,
        testTag = "nav_dashboard"
    ),
    NavDestination(
        section = StoreSection.INVENTORY,
        label = "Stock",
        selectedIcon = Icons.Filled.Inventory2,
        unselectedIcon = Icons.Outlined.Inventory2,
        testTag = "nav_inventory"
    ),
    NavDestination(
        section = StoreSection.POS_SALES,
        label = "POS",
        selectedIcon = Icons.Filled.PointOfSale,
        unselectedIcon = Icons.Outlined.PointOfSale,
        testTag = "nav_pos"
    ),
    NavDestination(
        section = StoreSection.CUSTOMER_DUES,
        label = "Due",
        selectedIcon = Icons.Filled.AccountBalanceWallet,
        unselectedIcon = Icons.Outlined.AccountBalanceWallet,
        testTag = "nav_customer_due"
    ),
    NavDestination(
        section = StoreSection.SUPPLIERS,
        label = "Vendors",
        selectedIcon = Icons.Filled.LocalShipping,
        unselectedIcon = Icons.Outlined.LocalShipping,
        testTag = "nav_suppliers"
    )
)

@Composable
fun StoreFlowApp(storeViewModel: StoreViewModel = viewModel()) {
    val context = LocalContext.current
    val products by storeViewModel.products.collectAsStateWithLifecycle()
    val suppliers by storeViewModel.suppliers.collectAsStateWithLifecycle()
    val sales by storeViewModel.sales.collectAsStateWithLifecycle()
    val stockMovements by storeViewModel.stockMovements.collectAsStateWithLifecycle()
    val purchaseOrders by storeViewModel.purchaseOrders.collectAsStateWithLifecycle()
    val customerDues by storeViewModel.customerDues.collectAsStateWithLifecycle()
    val dueTransactions by storeViewModel.dueTransactions.collectAsStateWithLifecycle()
    val storeSettings by storeViewModel.storeSettings.collectAsStateWithLifecycle()
    val prefs by storeViewModel.prefs.collectAsStateWithLifecycle()
    val cart by storeViewModel.cart.collectAsStateWithLifecycle()

    var showOfflineDialog by remember { mutableStateOf(false) }
    var showStoreSettingsDialog by remember { mutableStateOf(false) }
    var showQuickCurrencyDialog by remember { mutableStateOf(false) }
    var isAppUnlocked by rememberSaveable { mutableStateOf(false) }

    activeCurrencySymbol = storeSettings.currencySymbol.ifBlank { "₹" }
    activeCurrencyCode = storeSettings.currencyCode.ifBlank { "INR" }

    // Auto-dismiss notification banner after 3 seconds so it doesn't take up screen space
    LaunchedEffect(prefs.statusBannerMessage) {
        if (prefs.statusBannerMessage != null) {
            delay(3000)
            storeViewModel.clearBannerMessage()
        }
    }

    // Show PIN Lock screen if PIN lock is enabled and app is not unlocked yet
    if (storeSettings.isPinLockEnabled && !isAppUnlocked) {
        PinLockScreen(
            storeName = storeSettings.storeName,
            expectedPin = storeSettings.appPinCode,
            onUnlocked = { isAppUnlocked = true },
            onUpdatePin = { newPin ->
                storeViewModel.saveStoreSettings(storeSettings.copy(appPinCode = newPin))
                isAppUnlocked = true
            }
        )
        return
    }

    // System back returns to Overview Dashboard when on secondary tabs
    BackHandler(enabled = prefs.currentSection != StoreSection.DASHBOARD) {
        storeViewModel.selectSection(StoreSection.DASHBOARD)
    }

    val lowStockCount = remember(products) {
        products.count { it.isLowStock || it.isOutOfStock }
    }
    val cartCount = remember(cart) {
        cart.sumOf { it.quantity }
    }
    val pendingPoCount = remember(purchaseOrders) {
        purchaseOrders.count { it.status == "PENDING" }
    }
    val pendingDueAccountsCount = remember(customerDues) {
        customerDues.count { it.dueBalance > 0 }
    }

    val dailyChartPoints = remember(sales) {
        storeViewModel.buildLast7DaysChart(sales)
    }
    val categorySlices = remember(sales, prefs.reportPeriod) {
        val now = System.currentTimeMillis()
        val periodSales = when (prefs.reportPeriod) {
            ReportPeriod.ALL_TIME -> sales
            ReportPeriod.LAST_7_DAYS -> sales.filter { it.timestamp >= now - 7 * 86_400_000L }
            ReportPeriod.TODAY -> sales.filter { it.timestamp >= now - 86_400_000L }
        }
        storeViewModel.buildCategoryBreakdown(periodSales)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpandedTablet = maxWidth >= 680.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                val isPinSaved = storeSettings.isPinLockEnabled || storeSettings.appPinCode != "1234"
                StoreTopAppBar(
                    storeName = storeSettings.storeName,
                    currencySymbol = storeSettings.currencySymbol.ifBlank { "₹" },
                    currencyCode = storeSettings.currencyCode.ifBlank { "INR" },
                    pinStatusText = if (isPinSaved) "PIN: ${storeSettings.appPinCode}" else "PIN: Default (1234)",
                    isExpandedTablet = isExpandedTablet,
                    strictOfflineMode = prefs.strictOfflineMode,
                    lowStockCount = lowStockCount,
                    onOpenOfflineCenter = { showOfflineDialog = true },
                    onOpenStoreSettings = { showStoreSettingsDialog = true },
                    onLockAppNow = {
                        if (!storeSettings.isPinLockEnabled) {
                            storeViewModel.saveStoreSettings(storeSettings.copy(isPinLockEnabled = true))
                        }
                        isAppUnlocked = false
                    },
                    onLowStockClick = {
                        storeViewModel.updateStockFilter(StockFilter.LOW_STOCK)
                        storeViewModel.selectSection(StoreSection.INVENTORY)
                    },
                    onQuickChangeCurrency = { showQuickCurrencyDialog = true }
                )
            },
            bottomBar = {
                if (!isExpandedTablet) {
                    NavigationBar {
                        NAV_DESTINATIONS.forEach { dest ->
                            val selected = prefs.currentSection == dest.section
                            val badgeVal = when (dest.section) {
                                StoreSection.INVENTORY -> lowStockCount
                                StoreSection.POS_SALES -> cartCount
                                StoreSection.CUSTOMER_DUES -> pendingDueAccountsCount
                                StoreSection.SUPPLIERS -> pendingPoCount
                                else -> 0
                            }

                            NavigationBarItem(
                                selected = selected,
                                onClick = { storeViewModel.selectSection(dest.section) },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (badgeVal > 0) {
                                                Badge { Text(badgeVal.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    }
                                },
                                label = {
                                    Text(
                                        text = dest.label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isExpandedTablet) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))
                        NAV_DESTINATIONS.forEach { dest ->
                            val selected = prefs.currentSection == dest.section
                            val badgeVal = when (dest.section) {
                                StoreSection.INVENTORY -> lowStockCount
                                StoreSection.POS_SALES -> cartCount
                                StoreSection.CUSTOMER_DUES -> pendingDueAccountsCount
                                StoreSection.SUPPLIERS -> pendingPoCount
                                else -> 0
                            }

                            NavigationRailItem(
                                selected = selected,
                                onClick = { storeViewModel.selectSection(dest.section) },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (badgeVal > 0) {
                                                Badge { Text(badgeVal.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    }
                                },
                                label = { Text(dest.label, maxLines = 1) },
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .testTag(dest.testTag)
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    AnimatedVisibility(visible = prefs.statusBannerMessage != null) {
                        prefs.statusBannerMessage?.let { msg ->
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = msg,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { storeViewModel.clearBannerMessage() },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Dismiss notification",
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        when (prefs.currentSection) {
                            StoreSection.DASHBOARD -> {
                                DashboardReportsScreen(
                                    isExpandedTablet = isExpandedTablet,
                                    storeSettings = storeSettings,
                                    products = products,
                                    sales = sales,
                                    purchaseOrders = purchaseOrders,
                                    customerDues = customerDues,
                                    selectedPeriod = prefs.reportPeriod,
                                    dailyChartPoints = dailyChartPoints,
                                    categorySlices = categorySlices,
                                    onSelectPeriod = storeViewModel::updateReportPeriod,
                                    onQuickRestockProduct = { prod ->
                                        storeViewModel.adjustStock(
                                            prod,
                                            15,
                                            "Quick +15 restock from Dashboard Low-Stock Alert"
                                        )
                                    },
                                    onNavigateToPos = {
                                        storeViewModel.selectSection(StoreSection.POS_SALES)
                                    },
                                    onNavigateToInventory = {
                                        storeViewModel.selectSection(StoreSection.INVENTORY)
                                    },
                                    onNavigateToCustomerDue = {
                                        storeViewModel.selectSection(StoreSection.CUSTOMER_DUES)
                                    },
                                    onOpenStoreSettings = {
                                        showStoreSettingsDialog = true
                                    },
                                    onExportCsvReport = {
                                        val csv = storeViewModel.generateCsvSalesAndInventoryReport(
                                            productsList = products,
                                            salesList = sales,
                                            suppliersList = suppliers,
                                            customerDuesList = customerDues,
                                            settings = storeSettings
                                        )
                                        shareTextReport(
                                            context = context,
                                            subject = "${storeSettings.storeName} - Full CSV Report",
                                            body = csv
                                        )
                                    }
                                )
                            }

                            StoreSection.INVENTORY -> {
                                InventoryScreen(
                                    isExpandedTablet = isExpandedTablet,
                                    products = products,
                                    suppliers = suppliers,
                                    stockMovements = stockMovements,
                                    searchQuery = prefs.searchQuery,
                                    selectedCategory = prefs.selectedCategory,
                                    stockFilter = prefs.stockFilter,
                                    selectedProductId = prefs.selectedProductId,
                                    onSearchQueryChange = storeViewModel::updateSearchQuery,
                                    onCategoryChange = storeViewModel::updateSelectedCategory,
                                    onStockFilterChange = storeViewModel::updateStockFilter,
                                    onSelectProduct = storeViewModel::selectProduct,
                                    onSaveProduct = storeViewModel::saveProduct,
                                    onDeleteProduct = storeViewModel::deleteProduct,
                                    onAdjustStock = storeViewModel::adjustStock,
                                    onAddToPosCart = { prod ->
                                        storeViewModel.addToCart(prod)
                                        storeViewModel.selectSection(StoreSection.POS_SALES)
                                    }
                                )
                            }

                            StoreSection.POS_SALES -> {
                                PosSalesScreen(
                                    isExpandedTablet = isExpandedTablet,
                                    products = products,
                                    salesHistory = sales,
                                    cartItems = cart,
                                    onAddToCart = storeViewModel::addToCart,
                                    onUpdateCartQty = storeViewModel::updateCartItemQuantity,
                                    onClearCart = storeViewModel::clearCart,
                                    onCompleteCheckout = storeViewModel::completeSaleCheckout
                                )
                            }

                            StoreSection.CUSTOMER_DUES -> {
                                CustomerDueScreen(
                                    isExpandedTablet = isExpandedTablet,
                                    customers = customerDues,
                                    dueTransactions = dueTransactions,
                                    storeSettings = storeSettings,
                                    searchQuery = prefs.customerSearchQuery,
                                    showOnlyPendingDues = prefs.showOnlyPendingDues,
                                    selectedCustomerId = prefs.selectedCustomerId,
                                    onSearchQueryChange = storeViewModel::updateCustomerSearch,
                                    onTogglePendingFilter = storeViewModel::toggleShowOnlyPendingDues,
                                    onSelectCustomer = storeViewModel::selectCustomer,
                                    onSaveCustomer = storeViewModel::saveCustomerDue,
                                    onAddCredit = storeViewModel::addCustomerCredit,
                                    onRecordPayment = storeViewModel::recordCustomerDuePayment,
                                    onDeleteCustomer = storeViewModel::deleteCustomerDue
                                )
                            }

                            StoreSection.SUPPLIERS -> {
                                SuppliersScreen(
                                    isExpandedTablet = isExpandedTablet,
                                    suppliers = suppliers,
                                    products = products,
                                    purchaseOrders = purchaseOrders,
                                    supplierSearchQuery = prefs.supplierSearchQuery,
                                    selectedSupplierId = prefs.selectedSupplierId,
                                    onSearchQueryChange = storeViewModel::updateSupplierSearch,
                                    onSelectSupplier = storeViewModel::selectSupplier,
                                    onSaveSupplier = storeViewModel::saveSupplier,
                                    onDeleteSupplier = storeViewModel::deleteSupplier,
                                    onCreatePurchaseOrder = storeViewModel::createPurchaseOrder,
                                    onReceivePurchaseOrder = storeViewModel::receivePurchaseOrder
                                )
                            }
                        }
                    }

                    AdMobTestNativeAdCard(
                        adUnitId = DEFAULT_TEST_NATIVE_AD_UNIT_ID,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }

    if (showQuickCurrencyDialog) {
        QuickCurrencySelectorDialog(
            currentSettings = storeSettings,
            onSaveSettings = storeViewModel::saveStoreSettings,
            onDismiss = { showQuickCurrencyDialog = false }
        )
    }

    if (showStoreSettingsDialog) {
        StoreSettingsDialog(
            currentSettings = storeSettings,
            onSaveSettings = storeViewModel::saveStoreSettings,
            onOpenOfflineBackupCenter = { showOfflineDialog = true },
            onDismiss = { showStoreSettingsDialog = false }
        )
    }

    if (showOfflineDialog) {
        OfflineBackupCenterDialog(
            strictOfflineMode = prefs.strictOfflineMode,
            autoLocalSnapshot = prefs.autoLocalSnapshot,
            lastSavedTimestamp = prefs.lastSavedTimestamp,
            productCount = products.size,
            salesCount = sales.size,
            supplierCount = suppliers.size,
            customerDueCount = customerDues.size,
            onToggleStrictOffline = storeViewModel::toggleStrictOfflineMode,
            onToggleAutoSnapshot = storeViewModel::toggleAutoLocalSnapshot,
            onExportFullReport = {
                val csv = storeViewModel.generateCsvSalesAndInventoryReport(
                    productsList = products,
                    salesList = sales,
                    suppliersList = suppliers,
                    customerDuesList = customerDues,
                    settings = storeSettings
                )
                shareTextReport(
                    context = context,
                    subject = "${storeSettings.storeName} Full Offline Database Export",
                    body = csv
                )
            },
            onRestoreSampleData = {
                storeViewModel.resetDemoData()
                showOfflineDialog = false
            },
            onDismiss = { showOfflineDialog = false }
        )
    }
}
