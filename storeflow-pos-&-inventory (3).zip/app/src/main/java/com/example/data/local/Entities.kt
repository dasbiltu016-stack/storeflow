package com.example.data.local

data class ProductEntity(
    val id: Long = 0,
    val sku: String,
    val name: String,
    val category: String,
    val stockQty: Int,
    val minStockLevel: Int,
    val unit: String,
    val costPrice: Double,
    val sellingPrice: Double,
    val supplierId: Long,
    val supplierName: String,
    val shelfLocation: String = "Aisle 1",
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val isLowStock: Boolean
        get() = stockQty in 1..minStockLevel

    val isOutOfStock: Boolean
        get() = stockQty <= 0

    val unitProfit: Double
        get() = (sellingPrice - costPrice).coerceAtLeast(0.0)

    val marginPercent: Double
        get() = if (sellingPrice > 0) ((sellingPrice - costPrice) / sellingPrice) * 100.0 else 0.0

    val stockValueAtCost: Double
        get() = stockQty.coerceAtLeast(0) * costPrice
}

data class SupplierEntity(
    val id: Long = 0,
    val name: String,
    val contactPerson: String,
    val phone: String,
    val email: String,
    val category: String,
    val leadTimeDays: Int,
    val rating: Float,
    val city: String,
    val notes: String,
    val activeOrdersCount: Int = 0
)

data class SaleRecordEntity(
    val id: Long = 0,
    val invoiceNumber: String,
    val customerName: String,
    val customerPhone: String,
    val itemsSummary: String,
    val totalItemsCount: Int,
    val totalAmount: Double,
    val totalProfit: Double,
    val paymentMethod: String,
    val primaryCategory: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class StockMovementEntity(
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val changeQty: Int,
    val resultingStock: Int,
    val movementType: String, // "SALE", "RESTOCK", "MANUAL_ADJUST"
    val note: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class PurchaseOrderEntity(
    val id: Long = 0,
    val poNumber: String,
    val supplierId: Long,
    val supplierName: String,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitCost: Double,
    val totalCost: Double,
    val status: String, // "PENDING", "RECEIVED"
    val createdAt: Long = System.currentTimeMillis(),
    val receivedAt: Long? = null
)

data class CustomerDueEntity(
    val id: Long = 0,
    val customerName: String,
    val phone: String,
    val address: String,
    val totalCreditGiven: Double,
    val totalPaidAmount: Double,
    val dueBalance: Double,
    val lastTransactionNote: String,
    val dueDateNote: String = "Monthly Due",
    val lastUpdated: Long = System.currentTimeMillis()
)

data class DueTransactionEntity(
    val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val amount: Double,
    val type: String, // "CREDIT_GIVEN" or "PAYMENT_RECEIVED"
    val paymentMode: String, // "Due / Credit", "UPI", "Cash", "Card"
    val note: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class StoreSettingsEntity(
    val id: Int = 1,
    val storeName: String = "StoreFlow Supermart",
    val ownerName: String = "Ramesh Sharma",
    val storePhone: String = "+91 98201 55432",
    val storeAddress: String = "Shop 12, Main Market Road, Indore",
    val gstNumber: String = "23AABCS1429B1Z5",
    val upiId: String = "storeflow@upi",
    val defaultTaxPercent: Double = 0.0,
    val defaultLowStockThreshold: Int = 10,
    val receiptFooterNote: String = "Thank you for shopping at StoreFlow! Goods once sold will be exchanged within 7 days.",
    val enableLowStockBanner: Boolean = true,
    val appPinCode: String = "1234",
    val isPinLockEnabled: Boolean = false,
    val adUnitId: String = "ca-app-pub-3940256099942544/2247696110",
    val enableAds: Boolean = true,
    val currencySymbol: String = "₹",
    val currencyCode: String = "INR"
)
