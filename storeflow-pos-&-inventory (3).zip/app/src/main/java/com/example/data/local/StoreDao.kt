package com.example.data.local

import kotlinx.coroutines.flow.Flow

interface StoreDao {
    // --- Products ---
    fun getAllProducts(): Flow<List<ProductEntity>>
    suspend fun getProductById(id: Long): ProductEntity?
    suspend fun getProductCount(): Int
    suspend fun insertProduct(product: ProductEntity): Long
    suspend fun insertProducts(products: List<ProductEntity>)
    suspend fun updateProduct(product: ProductEntity)
    suspend fun deleteProduct(product: ProductEntity)
    suspend fun deleteAllProducts()

    // --- Suppliers ---
    fun getAllSuppliers(): Flow<List<SupplierEntity>>
    suspend fun insertSupplier(supplier: SupplierEntity): Long
    suspend fun insertSuppliers(suppliers: List<SupplierEntity>)
    suspend fun updateSupplier(supplier: SupplierEntity)
    suspend fun deleteSupplier(supplier: SupplierEntity)
    suspend fun deleteAllSuppliers()

    // --- Sales Records ---
    fun getAllSales(): Flow<List<SaleRecordEntity>>
    suspend fun insertSale(sale: SaleRecordEntity): Long
    suspend fun insertSales(sales: List<SaleRecordEntity>)
    suspend fun deleteAllSales()

    // --- Stock Movements ---
    fun getRecentStockMovements(): Flow<List<StockMovementEntity>>
    suspend fun insertStockMovement(movement: StockMovementEntity): Long
    suspend fun insertStockMovements(movements: List<StockMovementEntity>)
    suspend fun deleteAllStockMovements()

    // --- Purchase Orders ---
    fun getAllPurchaseOrders(): Flow<List<PurchaseOrderEntity>>
    suspend fun insertPurchaseOrder(order: PurchaseOrderEntity): Long
    suspend fun insertPurchaseOrders(orders: List<PurchaseOrderEntity>)
    suspend fun updatePurchaseOrder(order: PurchaseOrderEntity)
    suspend fun deleteAllPurchaseOrders()

    // --- Customer Dues (Khata / Udhaar) ---
    fun getAllCustomerDues(): Flow<List<CustomerDueEntity>>
    suspend fun getCustomerDueById(id: Long): CustomerDueEntity?
    suspend fun findCustomerByNameOrPhone(name: String, phone: String): CustomerDueEntity?
    suspend fun insertCustomerDue(customer: CustomerDueEntity): Long
    suspend fun insertCustomerDues(customers: List<CustomerDueEntity>)
    suspend fun updateCustomerDue(customer: CustomerDueEntity)
    suspend fun deleteCustomerDue(customer: CustomerDueEntity)
    suspend fun deleteAllCustomerDues()

    // --- Due Transactions (Khata Ledger) ---
    fun getAllDueTransactions(): Flow<List<DueTransactionEntity>>
    suspend fun insertDueTransaction(tx: DueTransactionEntity): Long
    suspend fun insertDueTransactions(txs: List<DueTransactionEntity>)
    suspend fun deleteAllDueTransactions()

    // --- Store Settings ---
    fun getStoreSettings(): Flow<StoreSettingsEntity?>
    suspend fun getStoreSettingsOnce(): StoreSettingsEntity?
    suspend fun saveStoreSettings(settings: StoreSettingsEntity)

    // --- Transactional Business Operations ---
    suspend fun adjustProductStock(
        productId: Long,
        deltaQty: Int,
        movementType: String,
        note: String
    ) {
        val product = getProductById(productId) ?: return
        val newStock = (product.stockQty + deltaQty).coerceAtLeast(0)
        updateProduct(
            product.copy(
                stockQty = newStock,
                lastUpdated = System.currentTimeMillis()
            )
        )
        insertStockMovement(
            StockMovementEntity(
                productId = product.id,
                productName = product.name,
                changeQty = deltaQty,
                resultingStock = newStock,
                movementType = movementType,
                note = note,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun receiveSupplierOrder(order: PurchaseOrderEntity) {
        if (order.status == "RECEIVED") return
        val now = System.currentTimeMillis()
        updatePurchaseOrder(
            order.copy(
                status = "RECEIVED",
                receivedAt = now
            )
        )
        val product = getProductById(order.productId)
        if (product != null) {
            val newStock = product.stockQty + order.quantity
            updateProduct(
                product.copy(
                    stockQty = newStock,
                    costPrice = order.unitCost,
                    lastUpdated = now
                )
            )
            insertStockMovement(
                StockMovementEntity(
                    productId = product.id,
                    productName = product.name,
                    changeQty = order.quantity,
                    resultingStock = newStock,
                    movementType = "RESTOCK",
                    note = "PO ${order.poNumber} from ${order.supplierName}",
                    timestamp = now
                )
            )
        }
    }

    suspend fun addCreditToCustomer(
        customerId: Long,
        amount: Double,
        note: String
    ) {
        val customer = getCustomerDueById(customerId) ?: return
        val now = System.currentTimeMillis()
        val newCredit = customer.totalCreditGiven + amount
        val newDue = (customer.dueBalance + amount).coerceAtLeast(0.0)
        updateCustomerDue(
            customer.copy(
                totalCreditGiven = newCredit,
                dueBalance = newDue,
                lastTransactionNote = note,
                lastUpdated = now
            )
        )
        insertDueTransaction(
            DueTransactionEntity(
                customerId = customer.id,
                customerName = customer.customerName,
                amount = amount,
                type = "CREDIT_GIVEN",
                paymentMode = "Due / Credit",
                note = note,
                timestamp = now
            )
        )
    }

    suspend fun recordDuePaymentFromCustomer(
        customerId: Long,
        paymentAmount: Double,
        paymentMode: String,
        note: String
    ) {
        val customer = getCustomerDueById(customerId) ?: return
        val now = System.currentTimeMillis()
        val newPaid = customer.totalPaidAmount + paymentAmount
        val newDue = (customer.dueBalance - paymentAmount).coerceAtLeast(0.0)
        updateCustomerDue(
            customer.copy(
                totalPaidAmount = newPaid,
                dueBalance = newDue,
                lastTransactionNote = note,
                lastUpdated = now
            )
        )
        insertDueTransaction(
            DueTransactionEntity(
                customerId = customer.id,
                customerName = customer.customerName,
                amount = paymentAmount,
                type = "PAYMENT_RECEIVED",
                paymentMode = paymentMode,
                note = note,
                timestamp = now
            )
        )
    }
}
