package com.example.data.local

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class StoreDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "storeflow_offline.db", null, 6),
    StoreDao {

    private val productsFlow = MutableStateFlow<List<ProductEntity>>(emptyList())
    private val suppliersFlow = MutableStateFlow<List<SupplierEntity>>(emptyList())
    private val salesFlow = MutableStateFlow<List<SaleRecordEntity>>(emptyList())
    private val movementsFlow = MutableStateFlow<List<StockMovementEntity>>(emptyList())
    private val ordersFlow = MutableStateFlow<List<PurchaseOrderEntity>>(emptyList())
    private val customerDuesFlow = MutableStateFlow<List<CustomerDueEntity>>(emptyList())
    private val dueTransactionsFlow = MutableStateFlow<List<DueTransactionEntity>>(emptyList())
    private val settingsFlow = MutableStateFlow<StoreSettingsEntity?>(null)

    init {
        refreshAllFlowsSync()
    }

    fun storeDao(): StoreDao = this

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sku TEXT NOT NULL,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                stockQty INTEGER NOT NULL,
                minStockLevel INTEGER NOT NULL,
                unit TEXT NOT NULL,
                costPrice REAL NOT NULL,
                sellingPrice REAL NOT NULL,
                supplierId INTEGER NOT NULL,
                supplierName TEXT NOT NULL,
                shelfLocation TEXT NOT NULL,
                lastUpdated INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS suppliers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                contactPerson TEXT NOT NULL,
                phone TEXT NOT NULL,
                email TEXT NOT NULL,
                category TEXT NOT NULL,
                leadTimeDays INTEGER NOT NULL,
                rating REAL NOT NULL,
                city TEXT NOT NULL,
                notes TEXT NOT NULL,
                activeOrdersCount INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS sales_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoiceNumber TEXT NOT NULL,
                customerName TEXT NOT NULL,
                customerPhone TEXT NOT NULL,
                itemsSummary TEXT NOT NULL,
                totalItemsCount INTEGER NOT NULL,
                totalAmount REAL NOT NULL,
                totalProfit REAL NOT NULL,
                paymentMethod TEXT NOT NULL,
                primaryCategory TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS stock_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                productId INTEGER NOT NULL,
                productName TEXT NOT NULL,
                changeQty INTEGER NOT NULL,
                resultingStock INTEGER NOT NULL,
                movementType TEXT NOT NULL,
                note TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS purchase_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                poNumber TEXT NOT NULL,
                supplierId INTEGER NOT NULL,
                supplierName TEXT NOT NULL,
                productId INTEGER NOT NULL,
                productName TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unitCost REAL NOT NULL,
                totalCost REAL NOT NULL,
                status TEXT NOT NULL,
                createdAt INTEGER NOT NULL,
                receivedAt INTEGER
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS customer_dues (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customerName TEXT NOT NULL,
                phone TEXT NOT NULL,
                address TEXT NOT NULL,
                totalCreditGiven REAL NOT NULL,
                totalPaidAmount REAL NOT NULL,
                dueBalance REAL NOT NULL,
                lastTransactionNote TEXT NOT NULL,
                dueDateNote TEXT NOT NULL,
                lastUpdated INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS due_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customerId INTEGER NOT NULL,
                customerName TEXT NOT NULL,
                amount REAL NOT NULL,
                type TEXT NOT NULL,
                paymentMode TEXT NOT NULL,
                note TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS store_settings (
                id INTEGER PRIMARY KEY,
                storeName TEXT NOT NULL,
                ownerName TEXT NOT NULL,
                storePhone TEXT NOT NULL,
                storeAddress TEXT NOT NULL,
                gstNumber TEXT NOT NULL,
                upiId TEXT NOT NULL,
                defaultTaxPercent REAL NOT NULL,
                defaultLowStockThreshold INTEGER NOT NULL,
                receiptFooterNote TEXT NOT NULL,
                enableLowStockBanner INTEGER NOT NULL,
                appPinCode TEXT NOT NULL,
                isPinLockEnabled INTEGER NOT NULL,
                adUnitId TEXT NOT NULL,
                enableAds INTEGER NOT NULL,
                currencySymbol TEXT NOT NULL DEFAULT '₹',
                currencyCode TEXT NOT NULL DEFAULT 'INR'
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 5) {
            db.execSQL("DROP TABLE IF EXISTS products")
            db.execSQL("DROP TABLE IF EXISTS suppliers")
            db.execSQL("DROP TABLE IF EXISTS sales_records")
            db.execSQL("DROP TABLE IF EXISTS stock_movements")
            db.execSQL("DROP TABLE IF EXISTS purchase_orders")
            db.execSQL("DROP TABLE IF EXISTS customer_dues")
            db.execSQL("DROP TABLE IF EXISTS due_transactions")
            db.execSQL("DROP TABLE IF EXISTS store_settings")
            onCreate(db)
        } else if (oldVersion < 6) {
            try {
                db.execSQL("ALTER TABLE store_settings ADD COLUMN currencySymbol TEXT NOT NULL DEFAULT '₹'")
            } catch (_: Exception) {}
            try {
                db.execSQL("ALTER TABLE store_settings ADD COLUMN currencyCode TEXT NOT NULL DEFAULT 'INR'")
            } catch (_: Exception) {}
            try {
                db.execSQL("UPDATE store_settings SET isPinLockEnabled = 0 WHERE appPinCode = '1234'")
            } catch (_: Exception) {}
        }
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onUpgrade(db, oldVersion, newVersion)
    }

    private fun refreshAllFlowsSync() {
        productsFlow.value = queryProductsSync()
        suppliersFlow.value = querySuppliersSync()
        salesFlow.value = querySalesSync()
        movementsFlow.value = queryMovementsSync()
        ordersFlow.value = queryOrdersSync()
        customerDuesFlow.value = queryCustomerDuesSync()
        dueTransactionsFlow.value = queryDueTransactionsSync()
        settingsFlow.value = querySettingsSync()
    }

    private fun queryProductsSync(): List<ProductEntity> {
        val list = mutableListOf<ProductEntity>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY name ASC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    ProductEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        sku = c.getString(c.getColumnIndexOrThrow("sku")),
                        name = c.getString(c.getColumnIndexOrThrow("name")),
                        category = c.getString(c.getColumnIndexOrThrow("category")),
                        stockQty = c.getInt(c.getColumnIndexOrThrow("stockQty")),
                        minStockLevel = c.getInt(c.getColumnIndexOrThrow("minStockLevel")),
                        unit = c.getString(c.getColumnIndexOrThrow("unit")),
                        costPrice = c.getDouble(c.getColumnIndexOrThrow("costPrice")),
                        sellingPrice = c.getDouble(c.getColumnIndexOrThrow("sellingPrice")),
                        supplierId = c.getLong(c.getColumnIndexOrThrow("supplierId")),
                        supplierName = c.getString(c.getColumnIndexOrThrow("supplierName")),
                        shelfLocation = c.getString(c.getColumnIndexOrThrow("shelfLocation")),
                        lastUpdated = c.getLong(c.getColumnIndexOrThrow("lastUpdated"))
                    )
                )
            }
        }
        return list
    }

    private fun querySuppliersSync(): List<SupplierEntity> {
        val list = mutableListOf<SupplierEntity>()
        readableDatabase.rawQuery("SELECT * FROM suppliers ORDER BY name ASC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    SupplierEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        name = c.getString(c.getColumnIndexOrThrow("name")),
                        contactPerson = c.getString(c.getColumnIndexOrThrow("contactPerson")),
                        phone = c.getString(c.getColumnIndexOrThrow("phone")),
                        email = c.getString(c.getColumnIndexOrThrow("email")),
                        category = c.getString(c.getColumnIndexOrThrow("category")),
                        leadTimeDays = c.getInt(c.getColumnIndexOrThrow("leadTimeDays")),
                        rating = c.getFloat(c.getColumnIndexOrThrow("rating")),
                        city = c.getString(c.getColumnIndexOrThrow("city")),
                        notes = c.getString(c.getColumnIndexOrThrow("notes")),
                        activeOrdersCount = c.getInt(c.getColumnIndexOrThrow("activeOrdersCount"))
                    )
                )
            }
        }
        return list
    }

    private fun querySalesSync(): List<SaleRecordEntity> {
        val list = mutableListOf<SaleRecordEntity>()
        readableDatabase.rawQuery("SELECT * FROM sales_records ORDER BY timestamp DESC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    SaleRecordEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        invoiceNumber = c.getString(c.getColumnIndexOrThrow("invoiceNumber")),
                        customerName = c.getString(c.getColumnIndexOrThrow("customerName")),
                        customerPhone = c.getString(c.getColumnIndexOrThrow("customerPhone")),
                        itemsSummary = c.getString(c.getColumnIndexOrThrow("itemsSummary")),
                        totalItemsCount = c.getInt(c.getColumnIndexOrThrow("totalItemsCount")),
                        totalAmount = c.getDouble(c.getColumnIndexOrThrow("totalAmount")),
                        totalProfit = c.getDouble(c.getColumnIndexOrThrow("totalProfit")),
                        paymentMethod = c.getString(c.getColumnIndexOrThrow("paymentMethod")),
                        primaryCategory = c.getString(c.getColumnIndexOrThrow("primaryCategory")),
                        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        return list
    }

    private fun queryMovementsSync(): List<StockMovementEntity> {
        val list = mutableListOf<StockMovementEntity>()
        readableDatabase.rawQuery("SELECT * FROM stock_movements ORDER BY timestamp DESC LIMIT 120", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    StockMovementEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        productId = c.getLong(c.getColumnIndexOrThrow("productId")),
                        productName = c.getString(c.getColumnIndexOrThrow("productName")),
                        changeQty = c.getInt(c.getColumnIndexOrThrow("changeQty")),
                        resultingStock = c.getInt(c.getColumnIndexOrThrow("resultingStock")),
                        movementType = c.getString(c.getColumnIndexOrThrow("movementType")),
                        note = c.getString(c.getColumnIndexOrThrow("note")),
                        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        return list
    }

    private fun queryOrdersSync(): List<PurchaseOrderEntity> {
        val list = mutableListOf<PurchaseOrderEntity>()
        readableDatabase.rawQuery("SELECT * FROM purchase_orders ORDER BY createdAt DESC", null).use { c ->
            while (c.moveToNext()) {
                val recIdx = c.getColumnIndexOrThrow("receivedAt")
                list.add(
                    PurchaseOrderEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        poNumber = c.getString(c.getColumnIndexOrThrow("poNumber")),
                        supplierId = c.getLong(c.getColumnIndexOrThrow("supplierId")),
                        supplierName = c.getString(c.getColumnIndexOrThrow("supplierName")),
                        productId = c.getLong(c.getColumnIndexOrThrow("productId")),
                        productName = c.getString(c.getColumnIndexOrThrow("productName")),
                        quantity = c.getInt(c.getColumnIndexOrThrow("quantity")),
                        unitCost = c.getDouble(c.getColumnIndexOrThrow("unitCost")),
                        totalCost = c.getDouble(c.getColumnIndexOrThrow("totalCost")),
                        status = c.getString(c.getColumnIndexOrThrow("status")),
                        createdAt = c.getLong(c.getColumnIndexOrThrow("createdAt")),
                        receivedAt = if (c.isNull(recIdx)) null else c.getLong(recIdx)
                    )
                )
            }
        }
        return list
    }

    private fun queryCustomerDuesSync(): List<CustomerDueEntity> {
        val list = mutableListOf<CustomerDueEntity>()
        readableDatabase.rawQuery(
            "SELECT * FROM customer_dues ORDER BY dueBalance DESC, lastUpdated DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    CustomerDueEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        customerName = c.getString(c.getColumnIndexOrThrow("customerName")),
                        phone = c.getString(c.getColumnIndexOrThrow("phone")),
                        address = c.getString(c.getColumnIndexOrThrow("address")),
                        totalCreditGiven = c.getDouble(c.getColumnIndexOrThrow("totalCreditGiven")),
                        totalPaidAmount = c.getDouble(c.getColumnIndexOrThrow("totalPaidAmount")),
                        dueBalance = c.getDouble(c.getColumnIndexOrThrow("dueBalance")),
                        lastTransactionNote = c.getString(c.getColumnIndexOrThrow("lastTransactionNote")),
                        dueDateNote = c.getString(c.getColumnIndexOrThrow("dueDateNote")),
                        lastUpdated = c.getLong(c.getColumnIndexOrThrow("lastUpdated"))
                    )
                )
            }
        }
        return list
    }

    private fun queryDueTransactionsSync(): List<DueTransactionEntity> {
        val list = mutableListOf<DueTransactionEntity>()
        readableDatabase.rawQuery("SELECT * FROM due_transactions ORDER BY timestamp DESC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    DueTransactionEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        customerId = c.getLong(c.getColumnIndexOrThrow("customerId")),
                        customerName = c.getString(c.getColumnIndexOrThrow("customerName")),
                        amount = c.getDouble(c.getColumnIndexOrThrow("amount")),
                        type = c.getString(c.getColumnIndexOrThrow("type")),
                        paymentMode = c.getString(c.getColumnIndexOrThrow("paymentMode")),
                        note = c.getString(c.getColumnIndexOrThrow("note")),
                        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        return list
    }

    private fun querySettingsSync(): StoreSettingsEntity? {
        readableDatabase.rawQuery("SELECT * FROM store_settings WHERE id = 1 LIMIT 1", null).use { c ->
            if (c.moveToFirst()) {
                val curSymIdx = c.getColumnIndex("currencySymbol")
                val curCodeIdx = c.getColumnIndex("currencyCode")
                return StoreSettingsEntity(
                    id = c.getInt(c.getColumnIndexOrThrow("id")),
                    storeName = c.getString(c.getColumnIndexOrThrow("storeName")),
                    ownerName = c.getString(c.getColumnIndexOrThrow("ownerName")),
                    storePhone = c.getString(c.getColumnIndexOrThrow("storePhone")),
                    storeAddress = c.getString(c.getColumnIndexOrThrow("storeAddress")),
                    gstNumber = c.getString(c.getColumnIndexOrThrow("gstNumber")),
                    upiId = c.getString(c.getColumnIndexOrThrow("upiId")),
                    defaultTaxPercent = c.getDouble(c.getColumnIndexOrThrow("defaultTaxPercent")),
                    defaultLowStockThreshold = c.getInt(c.getColumnIndexOrThrow("defaultLowStockThreshold")),
                    receiptFooterNote = c.getString(c.getColumnIndexOrThrow("receiptFooterNote")),
                    enableLowStockBanner = c.getInt(c.getColumnIndexOrThrow("enableLowStockBanner")) != 0,
                    appPinCode = c.getString(c.getColumnIndexOrThrow("appPinCode")),
                    isPinLockEnabled = c.getInt(c.getColumnIndexOrThrow("isPinLockEnabled")) != 0,
                    adUnitId = c.getString(c.getColumnIndexOrThrow("adUnitId")),
                    enableAds = c.getInt(c.getColumnIndexOrThrow("enableAds")) != 0,
                    currencySymbol = if (curSymIdx >= 0) c.getString(curSymIdx).ifBlank { "₹" } else "₹",
                    currencyCode = if (curCodeIdx >= 0) c.getString(curCodeIdx).ifBlank { "INR" } else "INR"
                )
            }
        }
        return null
    }

    override fun getAllProducts(): Flow<List<ProductEntity>> = productsFlow.asStateFlow()
    override fun getAllSuppliers(): Flow<List<SupplierEntity>> = suppliersFlow.asStateFlow()
    override fun getAllSales(): Flow<List<SaleRecordEntity>> = salesFlow.asStateFlow()
    override fun getRecentStockMovements(): Flow<List<StockMovementEntity>> = movementsFlow.asStateFlow()
    override fun getAllPurchaseOrders(): Flow<List<PurchaseOrderEntity>> = ordersFlow.asStateFlow()
    override fun getAllCustomerDues(): Flow<List<CustomerDueEntity>> = customerDuesFlow.asStateFlow()
    override fun getAllDueTransactions(): Flow<List<DueTransactionEntity>> = dueTransactionsFlow.asStateFlow()
    override fun getStoreSettings(): Flow<StoreSettingsEntity?> = settingsFlow.asStateFlow()

    override suspend fun getProductById(id: Long): ProductEntity? = withContext(Dispatchers.IO) {
        productsFlow.value.find { it.id == id } ?: queryProductsSync().find { it.id == id }
    }

    override suspend fun getProductCount(): Int = withContext(Dispatchers.IO) {
        queryProductsSync().size
    }

    override suspend fun insertProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            if (product.id != 0L) put("id", product.id)
            put("sku", product.sku)
            put("name", product.name)
            put("category", product.category)
            put("stockQty", product.stockQty)
            put("minStockLevel", product.minStockLevel)
            put("unit", product.unit)
            put("costPrice", product.costPrice)
            put("sellingPrice", product.sellingPrice)
            put("supplierId", product.supplierId)
            put("supplierName", product.supplierName)
            put("shelfLocation", product.shelfLocation)
            put("lastUpdated", product.lastUpdated)
        }
        val id = writableDatabase.insertWithOnConflict("products", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        productsFlow.value = queryProductsSync()
        id
    }

    override suspend fun insertProducts(products: List<ProductEntity>) = withContext(Dispatchers.IO) {
        writableDatabase.beginTransaction()
        try {
            products.forEach { product ->
                val cv = ContentValues().apply {
                    if (product.id != 0L) put("id", product.id)
                    put("sku", product.sku)
                    put("name", product.name)
                    put("category", product.category)
                    put("stockQty", product.stockQty)
                    put("minStockLevel", product.minStockLevel)
                    put("unit", product.unit)
                    put("costPrice", product.costPrice)
                    put("sellingPrice", product.sellingPrice)
                    put("supplierId", product.supplierId)
                    put("supplierName", product.supplierName)
                    put("shelfLocation", product.shelfLocation)
                    put("lastUpdated", product.lastUpdated)
                }
                writableDatabase.insertWithOnConflict("products", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
        productsFlow.value = queryProductsSync()
    }

    override suspend fun updateProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        insertProduct(product)
        Unit
    }

    override suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        writableDatabase.delete("products", "id = ?", arrayOf(product.id.toString()))
        productsFlow.value = queryProductsSync()
    }

    override suspend fun deleteAllProducts() = withContext(Dispatchers.IO) {
        writableDatabase.delete("products", null, null)
        productsFlow.value = emptyList()
    }

    override suspend fun insertSupplier(supplier: SupplierEntity): Long = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            if (supplier.id != 0L) put("id", supplier.id)
            put("name", supplier.name)
            put("contactPerson", supplier.contactPerson)
            put("phone", supplier.phone)
            put("email", supplier.email)
            put("category", supplier.category)
            put("leadTimeDays", supplier.leadTimeDays)
            put("rating", supplier.rating)
            put("city", supplier.city)
            put("notes", supplier.notes)
            put("activeOrdersCount", supplier.activeOrdersCount)
        }
        val id = writableDatabase.insertWithOnConflict("suppliers", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        suppliersFlow.value = querySuppliersSync()
        id
    }

    override suspend fun insertSuppliers(suppliers: List<SupplierEntity>) = withContext(Dispatchers.IO) {
        suppliers.forEach { insertSupplier(it) }
    }

    override suspend fun updateSupplier(supplier: SupplierEntity) = withContext(Dispatchers.IO) {
        insertSupplier(supplier)
        Unit
    }

    override suspend fun deleteSupplier(supplier: SupplierEntity) = withContext(Dispatchers.IO) {
        writableDatabase.delete("suppliers", "id = ?", arrayOf(supplier.id.toString()))
        suppliersFlow.value = querySuppliersSync()
    }

    override suspend fun deleteAllSuppliers() = withContext(Dispatchers.IO) {
        writableDatabase.delete("suppliers", null, null)
        suppliersFlow.value = emptyList()
    }

    override suspend fun insertSale(sale: SaleRecordEntity): Long = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            if (sale.id != 0L) put("id", sale.id)
            put("invoiceNumber", sale.invoiceNumber)
            put("customerName", sale.customerName)
            put("customerPhone", sale.customerPhone)
            put("itemsSummary", sale.itemsSummary)
            put("totalItemsCount", sale.totalItemsCount)
            put("totalAmount", sale.totalAmount)
            put("totalProfit", sale.totalProfit)
            put("paymentMethod", sale.paymentMethod)
            put("primaryCategory", sale.primaryCategory)
            put("timestamp", sale.timestamp)
        }
        val id = writableDatabase.insertWithOnConflict("sales_records", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        salesFlow.value = querySalesSync()
        id
    }

    override suspend fun insertSales(sales: List<SaleRecordEntity>) = withContext(Dispatchers.IO) {
        sales.forEach { insertSale(it) }
    }

    override suspend fun deleteAllSales() = withContext(Dispatchers.IO) {
        writableDatabase.delete("sales_records", null, null)
        salesFlow.value = emptyList()
    }

    override suspend fun insertStockMovement(movement: StockMovementEntity): Long = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            if (movement.id != 0L) put("id", movement.id)
            put("productId", movement.productId)
            put("productName", movement.productName)
            put("changeQty", movement.changeQty)
            put("resultingStock", movement.resultingStock)
            put("movementType", movement.movementType)
            put("note", movement.note)
            put("timestamp", movement.timestamp)
        }
        val id = writableDatabase.insertWithOnConflict("stock_movements", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        movementsFlow.value = queryMovementsSync()
        id
    }

    override suspend fun insertStockMovements(movements: List<StockMovementEntity>) = withContext(Dispatchers.IO) {
        movements.forEach { insertStockMovement(it) }
    }

    override suspend fun deleteAllStockMovements() = withContext(Dispatchers.IO) {
        writableDatabase.delete("stock_movements", null, null)
        movementsFlow.value = emptyList()
    }

    override suspend fun insertPurchaseOrder(order: PurchaseOrderEntity): Long = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            if (order.id != 0L) put("id", order.id)
            put("poNumber", order.poNumber)
            put("supplierId", order.supplierId)
            put("supplierName", order.supplierName)
            put("productId", order.productId)
            put("productName", order.productName)
            put("quantity", order.quantity)
            put("unitCost", order.unitCost)
            put("totalCost", order.totalCost)
            put("status", order.status)
            put("createdAt", order.createdAt)
            if (order.receivedAt != null) put("receivedAt", order.receivedAt) else putNull("receivedAt")
        }
        val id = writableDatabase.insertWithOnConflict("purchase_orders", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        ordersFlow.value = queryOrdersSync()
        id
    }

    override suspend fun insertPurchaseOrders(orders: List<PurchaseOrderEntity>) = withContext(Dispatchers.IO) {
        orders.forEach { insertPurchaseOrder(it) }
    }

    override suspend fun updatePurchaseOrder(order: PurchaseOrderEntity) = withContext(Dispatchers.IO) {
        insertPurchaseOrder(order)
        Unit
    }

    override suspend fun deleteAllPurchaseOrders() = withContext(Dispatchers.IO) {
        writableDatabase.delete("purchase_orders", null, null)
        ordersFlow.value = emptyList()
    }

    override suspend fun getCustomerDueById(id: Long): CustomerDueEntity? = withContext(Dispatchers.IO) {
        customerDuesFlow.value.find { it.id == id } ?: queryCustomerDuesSync().find { it.id == id }
    }

    override suspend fun findCustomerByNameOrPhone(name: String, phone: String): CustomerDueEntity? =
        withContext(Dispatchers.IO) {
            queryCustomerDuesSync().find {
                it.customerName.equals(name, ignoreCase = true) ||
                    (phone.isNotBlank() && it.phone == phone)
            }
        }

    override suspend fun insertCustomerDue(customer: CustomerDueEntity): Long = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            if (customer.id != 0L) put("id", customer.id)
            put("customerName", customer.customerName)
            put("phone", customer.phone)
            put("address", customer.address)
            put("totalCreditGiven", customer.totalCreditGiven)
            put("totalPaidAmount", customer.totalPaidAmount)
            put("dueBalance", customer.dueBalance)
            put("lastTransactionNote", customer.lastTransactionNote)
            put("dueDateNote", customer.dueDateNote)
            put("lastUpdated", customer.lastUpdated)
        }
        val id = writableDatabase.insertWithOnConflict("customer_dues", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        customerDuesFlow.value = queryCustomerDuesSync()
        id
    }

    override suspend fun insertCustomerDues(customers: List<CustomerDueEntity>) = withContext(Dispatchers.IO) {
        customers.forEach { insertCustomerDue(it) }
    }

    override suspend fun updateCustomerDue(customer: CustomerDueEntity) = withContext(Dispatchers.IO) {
        insertCustomerDue(customer)
        Unit
    }

    override suspend fun deleteCustomerDue(customer: CustomerDueEntity) = withContext(Dispatchers.IO) {
        writableDatabase.delete("customer_dues", "id = ?", arrayOf(customer.id.toString()))
        customerDuesFlow.value = queryCustomerDuesSync()
    }

    override suspend fun deleteAllCustomerDues() = withContext(Dispatchers.IO) {
        writableDatabase.delete("customer_dues", null, null)
        customerDuesFlow.value = emptyList()
    }

    override suspend fun insertDueTransaction(tx: DueTransactionEntity): Long = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            if (tx.id != 0L) put("id", tx.id)
            put("customerId", tx.customerId)
            put("customerName", tx.customerName)
            put("amount", tx.amount)
            put("type", tx.type)
            put("paymentMode", tx.paymentMode)
            put("note", tx.note)
            put("timestamp", tx.timestamp)
        }
        val id = writableDatabase.insertWithOnConflict("due_transactions", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        dueTransactionsFlow.value = queryDueTransactionsSync()
        id
    }

    override suspend fun insertDueTransactions(txs: List<DueTransactionEntity>) = withContext(Dispatchers.IO) {
        txs.forEach { insertDueTransaction(it) }
    }

    override suspend fun deleteAllDueTransactions() = withContext(Dispatchers.IO) {
        writableDatabase.delete("due_transactions", null, null)
        dueTransactionsFlow.value = emptyList()
    }

    override suspend fun getStoreSettingsOnce(): StoreSettingsEntity? = withContext(Dispatchers.IO) {
        querySettingsSync()
    }

    override suspend fun saveStoreSettings(settings: StoreSettingsEntity) = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            put("id", 1)
            put("storeName", settings.storeName)
            put("ownerName", settings.ownerName)
            put("storePhone", settings.storePhone)
            put("storeAddress", settings.storeAddress)
            put("gstNumber", settings.gstNumber)
            put("upiId", settings.upiId)
            put("defaultTaxPercent", settings.defaultTaxPercent)
            put("defaultLowStockThreshold", settings.defaultLowStockThreshold)
            put("receiptFooterNote", settings.receiptFooterNote)
            put("enableLowStockBanner", if (settings.enableLowStockBanner) 1 else 0)
            put("appPinCode", settings.appPinCode)
            put("isPinLockEnabled", if (settings.isPinLockEnabled) 1 else 0)
            put("adUnitId", settings.adUnitId)
            put("enableAds", if (settings.enableAds) 1 else 0)
            put("currencySymbol", settings.currencySymbol.ifBlank { "₹" })
            put("currencyCode", settings.currencyCode.ifBlank { "INR" })
        }
        writableDatabase.insertWithOnConflict("store_settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        settingsFlow.value = querySettingsSync()
    }

    companion object {
        @Volatile
        private var INSTANCE: StoreDatabase? = null

        fun getInstance(context: Context): StoreDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = StoreDatabase(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
