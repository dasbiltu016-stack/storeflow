package com.example.data.repository

import com.example.data.local.CustomerDueEntity
import com.example.data.local.DueTransactionEntity
import com.example.data.local.ProductEntity
import com.example.data.local.PurchaseOrderEntity
import com.example.data.local.SaleRecordEntity
import com.example.data.local.StockMovementEntity
import com.example.data.local.StoreDao
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.SupplierEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.Flow

data class CartItem(
    val product: ProductEntity,
    val quantity: Int
) {
    val lineTotal: Double
        get() = product.sellingPrice * quantity

    val lineProfit: Double
        get() = (product.sellingPrice - product.costPrice).coerceAtLeast(0.0) * quantity
}

class StoreRepository(private val dao: StoreDao) {
    val allProducts: Flow<List<ProductEntity>> = dao.getAllProducts()
    val allSuppliers: Flow<List<SupplierEntity>> = dao.getAllSuppliers()
    val allSales: Flow<List<SaleRecordEntity>> = dao.getAllSales()
    val recentMovements: Flow<List<StockMovementEntity>> = dao.getRecentStockMovements()
    val allPurchaseOrders: Flow<List<PurchaseOrderEntity>> = dao.getAllPurchaseOrders()
    val allCustomerDues: Flow<List<CustomerDueEntity>> = dao.getAllCustomerDues()
    val allDueTransactions: Flow<List<DueTransactionEntity>> = dao.getAllDueTransactions()
    val storeSettings: Flow<StoreSettingsEntity?> = dao.getStoreSettings()

    suspend fun ensureSeedDataLoaded() {
        if (dao.getStoreSettingsOnce() == null) {
            dao.saveStoreSettings(StoreSettingsEntity())
        }
        if (dao.getProductCount() == 0) {
            seedDefaultStoreData()
        }
    }

    suspend fun saveStoreSettings(settings: StoreSettingsEntity) {
        dao.saveStoreSettings(settings.copy(id = 1))
    }

    suspend fun saveProduct(product: ProductEntity) {
        if (product.id == 0L) {
            val newId = dao.insertProduct(product)
            dao.insertStockMovement(
                StockMovementEntity(
                    productId = newId,
                    productName = product.name,
                    changeQty = product.stockQty,
                    resultingStock = product.stockQty,
                    movementType = "RESTOCK",
                    note = "Initial inventory entry (${product.sku})"
                )
            )
        } else {
            dao.updateProduct(product.copy(lastUpdated = System.currentTimeMillis()))
        }
    }

    suspend fun deleteProduct(product: ProductEntity) {
        dao.deleteProduct(product)
    }

    suspend fun adjustStock(
        productId: Long,
        deltaQty: Int,
        movementType: String,
        note: String
    ) {
        dao.adjustProductStock(productId, deltaQty, movementType, note)
    }

    suspend fun saveSupplier(supplier: SupplierEntity) {
        if (supplier.id == 0L) {
            dao.insertSupplier(supplier)
        } else {
            dao.updateSupplier(supplier)
        }
    }

    suspend fun deleteSupplier(supplier: SupplierEntity) {
        dao.deleteSupplier(supplier)
    }

    suspend fun createPurchaseOrder(
        supplier: SupplierEntity,
        product: ProductEntity,
        quantity: Int,
        unitCost: Double
    ) {
        val poNum = "PO-${(1000..9999).random()}"
        val order = PurchaseOrderEntity(
            poNumber = poNum,
            supplierId = supplier.id,
            supplierName = supplier.name,
            productId = product.id,
            productName = product.name,
            quantity = quantity,
            unitCost = unitCost,
            totalCost = quantity * unitCost,
            status = "PENDING",
            createdAt = System.currentTimeMillis()
        )
        dao.insertPurchaseOrder(order)
    }

    suspend fun receivePurchaseOrder(order: PurchaseOrderEntity) {
        dao.receiveSupplierOrder(order)
    }

    // --- Customer Due (Khata) Operations ---
    suspend fun saveCustomerDue(customer: CustomerDueEntity) {
        val now = System.currentTimeMillis()
        if (customer.id == 0L) {
            val newId = dao.insertCustomerDue(customer.copy(lastUpdated = now))
            if (customer.dueBalance > 0) {
                dao.insertDueTransaction(
                    DueTransactionEntity(
                        customerId = newId,
                        customerName = customer.customerName,
                        amount = customer.dueBalance,
                        type = "CREDIT_GIVEN",
                        paymentMode = "Due / Credit",
                        note = customer.lastTransactionNote.ifBlank { "Opening Due Balance" },
                        timestamp = now
                    )
                )
            }
        } else {
            dao.updateCustomerDue(customer.copy(lastUpdated = now))
        }
    }

    suspend fun addCustomerCredit(customerId: Long, amount: Double, note: String) {
        if (amount <= 0) return
        dao.addCreditToCustomer(customerId, amount, note)
    }

    suspend fun recordCustomerDuePayment(
        customerId: Long,
        amount: Double,
        paymentMode: String,
        note: String
    ) {
        if (amount <= 0) return
        dao.recordDuePaymentFromCustomer(customerId, amount, paymentMode, note)
    }

    suspend fun deleteCustomerDue(customer: CustomerDueEntity) {
        dao.deleteCustomerDue(customer)
    }

    suspend fun recordSaleCheckout(
        cartItems: List<CartItem>,
        customerName: String,
        customerPhone: String,
        paymentMethod: String,
        discountAmount: Double
    ): SaleRecordEntity? {
        if (cartItems.isEmpty()) return null
        val now = System.currentTimeMillis()
        val invoiceNumber = "INV-${SimpleDateFormat("MMdd", Locale.US).format(Date(now))}-${(100..999).random()}"
        val totalItems = cartItems.sumOf { it.quantity }
        val grossTotal = cartItems.sumOf { it.lineTotal }
        val netTotal = (grossTotal - discountAmount).coerceAtLeast(0.0)
        val grossProfit = cartItems.sumOf { it.lineProfit }
        val netProfit = (grossProfit - discountAmount).coerceAtLeast(0.0)

        val summary = cartItems.joinToString(", ") { "${it.product.name} x${it.quantity}" }
        val dominantCategory = cartItems
            .groupBy { it.product.category }
            .maxByOrNull { entry -> entry.value.sumOf { it.lineTotal } }
            ?.key ?: "General"

        val finalCustomerName = customerName.trim().ifBlank {
            if (paymentMethod == "Due / Credit") "Due Customer" else "Walk-in Customer"
        }

        val sale = SaleRecordEntity(
            invoiceNumber = invoiceNumber,
            customerName = finalCustomerName,
            customerPhone = customerPhone.trim(),
            itemsSummary = summary,
            totalItemsCount = totalItems,
            totalAmount = netTotal,
            totalProfit = netProfit,
            paymentMethod = paymentMethod,
            primaryCategory = dominantCategory,
            timestamp = now
        )
        dao.insertSale(sale)

        cartItems.forEach { item ->
            dao.adjustProductStock(
                productId = item.product.id,
                deltaQty = -item.quantity,
                movementType = "SALE",
                note = "Sold via $invoiceNumber ($paymentMethod)"
            )
        }

        // Automatically record in Customer Due if payment mode is Due / Credit
        if (paymentMethod == "Due / Credit" && netTotal > 0) {
            val existingCustomer = dao.findCustomerByNameOrPhone(
                name = finalCustomerName,
                phone = customerPhone.trim()
            )
            if (existingCustomer != null) {
                dao.addCreditToCustomer(
                    customerId = existingCustomer.id,
                    amount = netTotal,
                    note = "POS Bill $invoiceNumber: $summary"
                )
            } else {
                val newCustId = dao.insertCustomerDue(
                    CustomerDueEntity(
                        customerName = finalCustomerName,
                        phone = customerPhone.trim().ifBlank { "+91 98000 00000" },
                        address = "Local Customer",
                        totalCreditGiven = netTotal,
                        totalPaidAmount = 0.0,
                        dueBalance = netTotal,
                        lastTransactionNote = "POS Bill $invoiceNumber: $summary",
                        dueDateNote = "Due within 15 days",
                        lastUpdated = now
                    )
                )
                dao.insertDueTransaction(
                    DueTransactionEntity(
                        customerId = newCustId,
                        customerName = finalCustomerName,
                        amount = netTotal,
                        type = "CREDIT_GIVEN",
                        paymentMode = "Due / Credit",
                        note = "POS Bill $invoiceNumber: $summary",
                        timestamp = now
                    )
                )
            }
        }

        return sale
    }

    suspend fun resetAndSeedSampleData() {
        dao.deleteAllPurchaseOrders()
        dao.deleteAllStockMovements()
        dao.deleteAllSales()
        dao.deleteAllProducts()
        dao.deleteAllSuppliers()
        dao.deleteAllDueTransactions()
        dao.deleteAllCustomerDues()
        dao.saveStoreSettings(StoreSettingsEntity())
        seedDefaultStoreData()
    }

    private suspend fun seedDefaultStoreData() {
        val now = System.currentTimeMillis()
        val dayMs = 86_400_000L

        val suppliers = listOf(
            SupplierEntity(
                id = 1L,
                name = "Bharat Agro & Grains Co.",
                contactPerson = "Rajesh Sharma",
                phone = "+91 98201 44510",
                email = "orders@bharatagro.in",
                category = "Groceries",
                leadTimeDays = 2,
                rating = 4.8f,
                city = "Indore",
                notes = "Primary wholesale supplier for basmati rice, atta, pulses, and cooking oils."
            ),
            SupplierEntity(
                id = 2L,
                name = "Deccan Beverages & Roasters",
                contactPerson = "Ananya Menon",
                phone = "+91 98450 77231",
                email = "supply@deccanbev.com",
                category = "Beverages",
                leadTimeDays = 3,
                rating = 4.7f,
                city = "Bengaluru",
                notes = "Specialty tea, filter coffee, cold-pressed juices, and health drinks."
            ),
            SupplierEntity(
                id = 3L,
                name = "Metro Retail Tech & Packaging",
                contactPerson = "Vikram Khanna",
                phone = "+91 98112 30988",
                email = "vikram@metroretail.in",
                category = "Electronics",
                leadTimeDays = 4,
                rating = 4.5f,
                city = "Delhi NCR",
                notes = "POS thermal rolls, barcode scanners, kitchen scales, and LED bulbs."
            ),
            SupplierEntity(
                id = 4L,
                name = "PureHome Essentials Pvt Ltd",
                contactPerson = "Sneha Kulkarni",
                phone = "+91 97654 11890",
                email = "dispatch@purehome.co.in",
                category = "Household",
                leadTimeDays = 2,
                rating = 4.9f,
                city = "Pune",
                notes = "Eco-friendly detergents, steel flasks, storage jars, and personal care."
            )
        )
        dao.insertSuppliers(suppliers)

        val products = listOf(
            ProductEntity(
                id = 1L,
                sku = "GRC-101",
                name = "Royal Basmati Rice (5 kg)",
                category = "Groceries",
                stockQty = 34,
                minStockLevel = 12,
                unit = "Bag",
                costPrice = 460.0,
                sellingPrice = 590.0,
                supplierId = 1L,
                supplierName = "Bharat Agro & Grains Co.",
                shelfLocation = "Aisle A1"
            ),
            ProductEntity(
                id = 2L,
                sku = "GRC-104",
                name = "Cold-Pressed Mustard Oil (1 L)",
                category = "Groceries",
                stockQty = 7,
                minStockLevel = 15,
                unit = "Bottle",
                costPrice = 165.0,
                sellingPrice = 220.0,
                supplierId = 1L,
                supplierName = "Bharat Agro & Grains Co.",
                shelfLocation = "Aisle A2"
            ),
            ProductEntity(
                id = 3L,
                sku = "BEV-201",
                name = "Assam Gold Leaf Tea (500 g)",
                category = "Beverages",
                stockQty = 42,
                minStockLevel = 15,
                unit = "Pack",
                costPrice = 180.0,
                sellingPrice = 250.0,
                supplierId = 2L,
                supplierName = "Deccan Beverages & Roasters",
                shelfLocation = "Aisle B1"
            ),
            ProductEntity(
                id = 4L,
                sku = "BEV-205",
                name = "Coorg Arabica Filter Coffee (250 g)",
                category = "Beverages",
                stockQty = 6,
                minStockLevel = 10,
                unit = "Pouch",
                costPrice = 210.0,
                sellingPrice = 295.0,
                supplierId = 2L,
                supplierName = "Deccan Beverages & Roasters",
                shelfLocation = "Aisle B2"
            ),
            ProductEntity(
                id = 5L,
                sku = "GRC-112",
                name = "Wild Forest Organic Honey (500 g)",
                category = "Groceries",
                stockQty = 19,
                minStockLevel = 8,
                unit = "Jar",
                costPrice = 240.0,
                sellingPrice = 340.0,
                supplierId = 1L,
                supplierName = "Bharat Agro & Grains Co.",
                shelfLocation = "Aisle A3"
            ),
            ProductEntity(
                id = 6L,
                sku = "HSH-301",
                name = "ThermoSteel Insulated Flask (1 L)",
                category = "Household",
                stockQty = 16,
                minStockLevel = 6,
                unit = "Piece",
                costPrice = 520.0,
                sellingPrice = 750.0,
                supplierId = 4L,
                supplierName = "PureHome Essentials Pvt Ltd",
                shelfLocation = "Aisle C1"
            ),
            ProductEntity(
                id = 7L,
                sku = "HSH-309",
                name = "Bio-Enzyme Liquid Detergent (2 L)",
                category = "Household",
                stockQty = 4,
                minStockLevel = 10,
                unit = "Can",
                costPrice = 275.0,
                sellingPrice = 380.0,
                supplierId = 4L,
                supplierName = "PureHome Essentials Pvt Ltd",
                shelfLocation = "Aisle C2"
            ),
            ProductEntity(
                id = 8L,
                sku = "ELC-401",
                name = "Thermal Receipt Paper Rolls (Pack of 10)",
                category = "Electronics",
                stockQty = 28,
                minStockLevel = 10,
                unit = "Box",
                costPrice = 310.0,
                sellingPrice = 450.0,
                supplierId = 3L,
                supplierName = "Metro Retail Tech & Packaging",
                shelfLocation = "Counter R1"
            ),
            ProductEntity(
                id = 9L,
                sku = "ELC-408",
                name = "Smart Digital Weighing Scale (30 kg)",
                category = "Electronics",
                stockQty = 5,
                minStockLevel = 3,
                unit = "Unit",
                costPrice = 1850.0,
                sellingPrice = 2490.0,
                supplierId = 3L,
                supplierName = "Metro Retail Tech & Packaging",
                shelfLocation = "Counter R2"
            ),
            ProductEntity(
                id = 10L,
                sku = "GRC-120",
                name = "California Almonds Premium (500 g)",
                category = "Groceries",
                stockQty = 22,
                minStockLevel = 10,
                unit = "Pack",
                costPrice = 390.0,
                sellingPrice = 520.0,
                supplierId = 1L,
                supplierName = "Bharat Agro & Grains Co.",
                shelfLocation = "Aisle A4"
            )
        )
        dao.insertProducts(products)

        val sampleSales = listOf(
            SaleRecordEntity(
                invoiceNumber = "INV-1021",
                customerName = "Meera Nair",
                customerPhone = "9820311200",
                itemsSummary = "Royal Basmati Rice (5 kg) x2, Assam Gold Leaf Tea x1",
                totalItemsCount = 3,
                totalAmount = 1430.0,
                totalProfit = 330.0,
                paymentMethod = "UPI",
                primaryCategory = "Groceries",
                timestamp = now - (2 * 3600_000L)
            ),
            SaleRecordEntity(
                invoiceNumber = "INV-1020",
                customerName = "Arjun Verma",
                customerPhone = "9811944210",
                itemsSummary = "ThermoSteel Insulated Flask x2, Coorg Filter Coffee x2",
                totalItemsCount = 4,
                totalAmount = 2090.0,
                totalProfit = 630.0,
                paymentMethod = "Card",
                primaryCategory = "Household",
                timestamp = now - (6 * 3600_000L)
            ),
            SaleRecordEntity(
                invoiceNumber = "INV-1019",
                customerName = "Kiran General Café",
                customerPhone = "9764098123",
                itemsSummary = "Assam Gold Leaf Tea x5, Thermal Receipt Rolls x2",
                totalItemsCount = 7,
                totalAmount = 2150.0,
                totalProfit = 630.0,
                paymentMethod = "UPI",
                primaryCategory = "Beverages",
                timestamp = now - dayMs - (3 * 3600_000L)
            ),
            SaleRecordEntity(
                invoiceNumber = "INV-1018",
                customerName = "Walk-in Customer",
                customerPhone = "",
                itemsSummary = "California Almonds (500 g) x3, Wild Forest Honey x2",
                totalItemsCount = 5,
                totalAmount = 2240.0,
                totalProfit = 590.0,
                paymentMethod = "Cash",
                primaryCategory = "Groceries",
                timestamp = now - (2 * dayMs)
            ),
            SaleRecordEntity(
                invoiceNumber = "INV-1017",
                customerName = "Suresh Provision Store",
                customerPhone = "9823019283",
                itemsSummary = "Smart Digital Weighing Scale x1, Thermal Receipt Rolls x1",
                totalItemsCount = 2,
                totalAmount = 2940.0,
                totalProfit = 780.0,
                paymentMethod = "UPI",
                primaryCategory = "Electronics",
                timestamp = now - (3 * dayMs)
            ),
            SaleRecordEntity(
                invoiceNumber = "INV-1016",
                customerName = "Priya Deshmukh",
                customerPhone = "9890123456",
                itemsSummary = "Bio-Enzyme Liquid Detergent x3, Cold-Pressed Mustard Oil x4",
                totalItemsCount = 7,
                totalAmount = 2020.0,
                totalProfit = 535.0,
                paymentMethod = "Due / Credit",
                primaryCategory = "Household",
                timestamp = now - (4 * dayMs)
            ),
            SaleRecordEntity(
                invoiceNumber = "INV-1015",
                customerName = "Rohan Kulkarni",
                customerPhone = "9845112233",
                itemsSummary = "Royal Basmati Rice (5 kg) x3, California Almonds x2",
                totalItemsCount = 5,
                totalAmount = 2810.0,
                totalProfit = 650.0,
                paymentMethod = "UPI",
                primaryCategory = "Groceries",
                timestamp = now - (5 * dayMs)
            ),
            SaleRecordEntity(
                invoiceNumber = "INV-1014",
                customerName = "Neha Joshi",
                customerPhone = "9822001144",
                itemsSummary = "Coorg Arabica Filter Coffee x4, Wild Forest Honey x2",
                totalItemsCount = 6,
                totalAmount = 1860.0,
                totalProfit = 540.0,
                paymentMethod = "Cash",
                primaryCategory = "Beverages",
                timestamp = now - (6 * dayMs)
            )
        )
        dao.insertSales(sampleSales)

        val purchaseOrders = listOf(
            PurchaseOrderEntity(
                poNumber = "PO-4821",
                supplierId = 1L,
                supplierName = "Bharat Agro & Grains Co.",
                productId = 2L,
                productName = "Cold-Pressed Mustard Oil (1 L)",
                quantity = 24,
                unitCost = 165.0,
                totalCost = 3960.0,
                status = "PENDING",
                createdAt = now - (5 * 3600_000L)
            ),
            PurchaseOrderEntity(
                poNumber = "PO-4819",
                supplierId = 4L,
                supplierName = "PureHome Essentials Pvt Ltd",
                productId = 7L,
                productName = "Bio-Enzyme Liquid Detergent (2 L)",
                quantity = 15,
                unitCost = 275.0,
                totalCost = 4125.0,
                status = "PENDING",
                createdAt = now - dayMs
            ),
            PurchaseOrderEntity(
                poNumber = "PO-4810",
                supplierId = 2L,
                supplierName = "Deccan Beverages & Roasters",
                productId = 3L,
                productName = "Assam Gold Leaf Tea (500 g)",
                quantity = 20,
                unitCost = 180.0,
                totalCost = 3600.0,
                status = "RECEIVED",
                createdAt = now - (4 * dayMs),
                receivedAt = now - (2 * dayMs)
            )
        )
        dao.insertPurchaseOrders(purchaseOrders)

        val movements = listOf(
            StockMovementEntity(
                productId = 1L,
                productName = "Royal Basmati Rice (5 kg)",
                changeQty = -2,
                resultingStock = 34,
                movementType = "SALE",
                note = "Sold via INV-1021 (UPI)",
                timestamp = now - (2 * 3600_000L)
            ),
            StockMovementEntity(
                productId = 6L,
                productName = "ThermoSteel Insulated Flask (1 L)",
                changeQty = -2,
                resultingStock = 16,
                movementType = "SALE",
                note = "Sold via INV-1020 (Card)",
                timestamp = now - (6 * 3600_000L)
            ),
            StockMovementEntity(
                productId = 3L,
                productName = "Assam Gold Leaf Tea (500 g)",
                changeQty = 20,
                resultingStock = 42,
                movementType = "RESTOCK",
                note = "PO PO-4810 from Deccan Beverages & Roasters",
                timestamp = now - (2 * dayMs)
            )
        )
        dao.insertStockMovements(movements)

        // Seed Customer Due Accounts
        val customers = listOf(
            CustomerDueEntity(
                id = 1L,
                customerName = "Priya Deshmukh",
                phone = "+91 98901 23456",
                address = "B-402 Green Valley Residency",
                totalCreditGiven = 3520.0,
                totalPaidAmount = 1500.0,
                dueBalance = 2020.0,
                lastTransactionNote = "POS Bill INV-1016: Detergent & Mustard Oil",
                dueDateNote = "Monthly Ration Due (5th of month)",
                lastUpdated = now - (4 * 3600_000L)
            ),
            CustomerDueEntity(
                id = 2L,
                customerName = "Hotel Annapurna & Tiffins",
                phone = "+91 98260 44112",
                address = "Near Clock Tower, Station Road",
                totalCreditGiven = 12400.0,
                totalPaidAmount = 7000.0,
                dueBalance = 5400.0,
                lastTransactionNote = "Bulk Basmati Rice 25kg & Tea Bags",
                dueDateNote = "Weekly Settlement (Sunday)",
                lastUpdated = now - dayMs
            ),
            CustomerDueEntity(
                id = 3L,
                customerName = "Deepak Tiwari",
                phone = "+91 97550 88991",
                address = "Lane 4, Shivaji Nagar",
                totalCreditGiven = 1850.0,
                totalPaidAmount = 1000.0,
                dueBalance = 850.0,
                lastTransactionNote = "Received ₹1,000 via UPI",
                dueDateNote = "15-Day Credit",
                lastUpdated = now - (2 * dayMs)
            ),
            CustomerDueEntity(
                id = 4L,
                customerName = "Kavita Agarwal",
                phone = "+91 98272 19004",
                address = "18 Saket Colony",
                totalCreditGiven = 2400.0,
                totalPaidAmount = 2400.0,
                dueBalance = 0.0,
                lastTransactionNote = "Full Due settled via Cash",
                dueDateNote = "Settled",
                lastUpdated = now - (3 * dayMs)
            )
        )
        dao.insertCustomerDues(customers)

        val dueTransactions = listOf(
            DueTransactionEntity(
                customerId = 1L,
                customerName = "Priya Deshmukh",
                amount = 2020.0,
                type = "CREDIT_GIVEN",
                paymentMode = "Due / Credit",
                note = "POS Bill INV-1016: Detergent & Mustard Oil",
                timestamp = now - (4 * 3600_000L)
            ),
            DueTransactionEntity(
                customerId = 1L,
                customerName = "Priya Deshmukh",
                amount = 1500.0,
                type = "PAYMENT_RECEIVED",
                paymentMode = "UPI",
                note = "Part payment received on UPI",
                timestamp = now - (2 * dayMs)
            ),
            DueTransactionEntity(
                customerId = 2L,
                customerName = "Hotel Annapurna & Tiffins",
                amount = 5400.0,
                type = "CREDIT_GIVEN",
                paymentMode = "Due / Credit",
                note = "Bulk Basmati Rice & Assam Tea supply",
                timestamp = now - dayMs
            ),
            DueTransactionEntity(
                customerId = 3L,
                customerName = "Deepak Tiwari",
                amount = 1000.0,
                type = "PAYMENT_RECEIVED",
                paymentMode = "UPI",
                note = "Part settlement received",
                timestamp = now - (2 * dayMs)
            )
        )
        dao.insertDueTransactions(dueTransactions)
    }
}
