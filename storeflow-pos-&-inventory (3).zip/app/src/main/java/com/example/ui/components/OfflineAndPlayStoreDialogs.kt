package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.StoreSettingsEntity
import com.example.ui.theme.StatusHealthyGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.FilterChip

fun shareTextReport(context: Context, subject: String, body: String) {
    val sendIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, body)
    }
    val chooser = Intent.createChooser(sendIntent, subject)
    context.startActivity(chooser)
}

@Composable
fun QuickCurrencySelectorDialog(
    currentSettings: StoreSettingsEntity,
    onSaveSettings: (StoreSettingsEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedSymbol by remember { mutableStateOf(currentSettings.currencySymbol.ifBlank { "₹" }) }
    var selectedCode by remember { mutableStateOf(currentSettings.currencyCode.ifBlank { "INR" }) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Select Store Currency (Multi-Currency)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Tap any currency below or type your own currency symbol:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                SUPPORTED_CURRENCIES.forEach { option ->
                    val isSelected = selectedCode.equals(option.code, ignoreCase = true) &&
                        selectedSymbol.trim() == option.symbol.trim()
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedSymbol = option.symbol
                            selectedCode = option.code
                        },
                        label = {
                            Text(
                                text = option.label,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                HorizontalDivider()

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = selectedSymbol,
                        onValueChange = { selectedSymbol = it.take(5) },
                        label = { Text("Custom Symbol (₹/৳/$)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = selectedCode,
                        onValueChange = { selectedCode = it.uppercase().take(5) },
                        label = { Text("Currency Code") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val sym = selectedSymbol.ifBlank { "₹" }
                    val code = selectedCode.ifBlank { "INR" }
                    activeCurrencySymbol = sym
                    activeCurrencyCode = code
                    onSaveSettings(
                        currentSettings.copy(
                            currencySymbol = sym,
                            currencyCode = code
                        )
                    )
                    onDismiss()
                },
                modifier = Modifier.testTag("confirm_currency_button")
            ) {
                Text("Apply Currency ($selectedSymbol)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun StoreSettingsDialog(
    currentSettings: StoreSettingsEntity,
    onSaveSettings: (StoreSettingsEntity) -> Unit,
    onOpenOfflineBackupCenter: () -> Unit,
    onDismiss: () -> Unit
) {
    var storeName by remember { mutableStateOf(currentSettings.storeName) }
    var ownerName by remember { mutableStateOf(currentSettings.ownerName) }
    var storePhone by remember { mutableStateOf(currentSettings.storePhone) }
    var storeAddress by remember { mutableStateOf(currentSettings.storeAddress) }
    var gstNumber by remember { mutableStateOf(currentSettings.gstNumber) }
    var upiId by remember { mutableStateOf(currentSettings.upiId) }
    var taxPercent by remember { mutableStateOf(currentSettings.defaultTaxPercent.toString()) }
    var lowStockThreshold by remember { mutableStateOf(currentSettings.defaultLowStockThreshold.toString()) }
    var receiptFooter by remember { mutableStateOf(currentSettings.receiptFooterNote) }
    var enableLowStockBanner by remember { mutableStateOf(currentSettings.enableLowStockBanner) }
    var appPinCode by remember { mutableStateOf(currentSettings.appPinCode.ifBlank { "1234" }) }
    var isPinLockEnabled by remember { mutableStateOf(currentSettings.isPinLockEnabled) }
    var currencySymbol by remember { mutableStateOf(currentSettings.currencySymbol.ifBlank { "₹" }) }
    var currencyCode by remember { mutableStateOf(currentSettings.currencyCode.ifBlank { "INR" }) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Store Settings",
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Store Settings, Currency & PIN",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Multi-Currency Card
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Multi-Currency Settings (${currencySymbol.trim()} $currencyCode)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SUPPORTED_CURRENCIES.forEach { option ->
                                FilterChip(
                                    selected = currencyCode.equals(option.code, ignoreCase = true),
                                    onClick = {
                                        currencySymbol = option.symbol
                                        currencyCode = option.code
                                    },
                                    label = { Text("${option.symbol.trim()} ${option.code}") }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = currencySymbol,
                                onValueChange = { currencySymbol = it.take(5) },
                                label = { Text("Currency Symbol") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = currencyCode,
                                onValueChange = { currencyCode = it.uppercase().take(5) },
                                label = { Text("Currency Code") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // App PIN Security Card at top of Store Settings
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isPinLockEnabled) "App PIN Active: $appPinCode" else "App PIN: Default (1234)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "Save a 4-digit PIN below to show & activate it on Home Page, or keep Default (1234).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Switch(
                                checked = isPinLockEnabled,
                                onCheckedChange = { isPinLockEnabled = it },
                                modifier = Modifier.testTag("settings_pin_enable_switch")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = appPinCode,
                                onValueChange = {
                                    val filtered = it.filter { ch -> ch.isDigit() }.take(4)
                                    appPinCode = filtered
                                    if (filtered.length == 4) {
                                        isPinLockEnabled = true
                                    }
                                },
                                label = { Text("4-Digit PIN (Save to Activate)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_pin_code_input")
                            )

                            OutlinedButton(
                                onClick = {
                                    appPinCode = "1234"
                                    isPinLockEnabled = false
                                }
                            ) {
                                Text("Default\n(1234)", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text("Store / Shop Name *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_store_name_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = ownerName,
                        onValueChange = { ownerName = it },
                        label = { Text("Owner Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = storePhone,
                        onValueChange = { storePhone = it },
                        label = { Text("Shop Phone") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = storeAddress,
                    onValueChange = { storeAddress = it },
                    label = { Text("Shop Address (Printed on Receipt)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = gstNumber,
                        onValueChange = { gstNumber = it.uppercase() },
                        label = { Text("Tax / Reg No.") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = upiId,
                        onValueChange = { upiId = it },
                        label = { Text("Store Payment / UPI ID") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settings_upi_id_input")
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = taxPercent,
                        onValueChange = { taxPercent = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Default Tax %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = lowStockThreshold,
                        onValueChange = { lowStockThreshold = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Low Stock Alert Qty") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = receiptFooter,
                    onValueChange = { receiptFooter = it },
                    label = { Text("Invoice Receipt Footer Message") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Low Stock Dashboard Alerts",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Highlight items below minimum stock threshold on the overview screen.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = enableLowStockBanner,
                        onCheckedChange = { enableLowStockBanner = it }
                    )
                }

                HorizontalDivider()

                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onOpenOfflineBackupCenter()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Storage, contentDescription = "Offline Backup", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Open Offline Backup & Data Reset Center")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (storeName.isNotBlank()) {
                        val validPin = if (appPinCode.length == 4) appPinCode else "1234"
                        val finalPinEnabled = if (validPin != "1234") true else isPinLockEnabled
                        val sym = currencySymbol.ifBlank { "₹" }
                        val code = currencyCode.ifBlank { "INR" }
                        activeCurrencySymbol = sym
                        activeCurrencyCode = code
                        onSaveSettings(
                            StoreSettingsEntity(
                                id = 1,
                                storeName = storeName.trim(),
                                ownerName = ownerName.trim().ifBlank { "Store Manager" },
                                storePhone = storePhone.trim(),
                                storeAddress = storeAddress.trim(),
                                gstNumber = gstNumber.trim(),
                                upiId = upiId.trim().ifBlank { "store@upi" },
                                defaultTaxPercent = taxPercent.toDoubleOrNull() ?: 0.0,
                                defaultLowStockThreshold = lowStockThreshold.toIntOrNull() ?: 10,
                                receiptFooterNote = receiptFooter.trim(),
                                enableLowStockBanner = enableLowStockBanner,
                                appPinCode = validPin,
                                isPinLockEnabled = finalPinEnabled,
                                adUnitId = DEFAULT_TEST_NATIVE_AD_UNIT_ID,
                                enableAds = true,
                                currencySymbol = sym,
                                currencyCode = code
                            )
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("save_store_settings_button")
            ) {
                Text("Save Settings")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun OfflineBackupCenterDialog(
    strictOfflineMode: Boolean,
    autoLocalSnapshot: Boolean,
    lastSavedTimestamp: Long,
    productCount: Int,
    salesCount: Int,
    supplierCount: Int,
    customerDueCount: Int = 0,
    onToggleStrictOffline: (Boolean) -> Unit,
    onToggleAutoSnapshot: (Boolean) -> Unit,
    onExportFullReport: () -> Unit,
    onRestoreSampleData: () -> Unit,
    onDismiss: () -> Unit
) {
    val formattedTime = remember(lastSavedTimestamp) {
        SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.US).format(Date(lastSavedTimestamp))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Storage,
                    contentDescription = "Offline SQLite Storage",
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Offline Capability & Local DB",
                    style = MaterialTheme.typography.titleLarge
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = StatusHealthyGreen.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Active",
                            tint = StatusHealthyGreen
                        )
                        Column {
                            Text(
                                text = "100% Offline-First Room SQLite Engine",
                                style = MaterialTheme.typography.titleSmall,
                                color = StatusHealthyGreen,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Works without internet on both Mobile & Tablet. Last local sync: $formattedTime",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Database Record Counters
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DbStatChip(label = "Products", count = productCount, modifier = Modifier.weight(1f))
                    DbStatChip(label = "Invoices", count = salesCount, modifier = Modifier.weight(1f))
                    DbStatChip(label = "Due", count = customerDueCount, modifier = Modifier.weight(1f))
                    DbStatChip(label = "Vendors", count = supplierCount, modifier = Modifier.weight(1f))
                }

                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Strict Offline Mode",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Keep all store billing, stock, customer dues & supplier records strictly on-device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = strictOfflineMode,
                        onCheckedChange = onToggleStrictOffline,
                        modifier = Modifier.testTag("strict_offline_switch")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Instant Transaction Auto-Commit",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Immediately commit every POS sale, customer due & stock change to local SQLite.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = autoLocalSnapshot,
                        onCheckedChange = onToggleAutoSnapshot
                    )
                }

                HorizontalDivider()

                Button(
                    onClick = onExportFullReport,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("export_csv_backup_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Export CSV",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Export / Share Full CSV Store Backup")
                }

                OutlinedButton(
                    onClick = onRestoreSampleData,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("restore_demo_data_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Restore Sample Data",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Reset & Reload Sample Store Dataset")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}

@Composable
private fun DbStatChip(label: String, count: Int, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun PlayStoreReadinessDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var copiedListing by remember { mutableStateOf(false) }
    var copiedPrivacy by remember { mutableStateOf(false) }

    val storeListingText = """
        App Title: StoreFlow POS & Inventory
        Package ID: com.aistudio.storeflow.kxpqmr
        Version: 1.0.0 (Version Code 1)
        Short Description: Offline-first retail store inventory tracker, POS billing, customer due & supplier manager.
        Full Description:
        StoreFlow POS & Inventory is an easy-to-use store management system designed for retail shops, supermarkets, kirana stores, and wholesale businesses.
        • Inventory Tracking: Monitor real-time stock quantities, low-stock alerts, cost & selling prices, and shelf locations.
        • Fast POS Billing & Sales Reports: Create invoices in seconds, automatically deduct stock, and view 7-day revenue & profit charts.
        • Customer Due Ledger: Track customer credit balances, record partial or full payments, and send WhatsApp/SMS payment reminders with UPI ID.
        • Supplier & Purchase Order Management: Manage wholesale vendors, lead times, and receive restock purchase orders with one tap.
        • Customizable Store Settings & 100% Offline Capability: Set your shop name, GSTIN, UPI ID, and work seamlessly offline on both Mobile and Tablet.
    """.trimIndent()

    val privacyPolicyText = """
        Privacy Policy for StoreFlow POS & Inventory
        1. Local Data Storage: StoreFlow POS & Inventory operates 100% offline. All inventory records, POS invoices, customer due balances, supplier records, and store settings are stored locally on your device using an on-device SQLite database.
        2. No Personal Data Collection: We do not collect, transmit, or sell any personal or business data to external servers.
        3. User-Initiated Sharing: Data is only shared when you explicitly tap Export CSV or Share Receipt/Reminder via your device's standard share sheet.
    """.trimIndent()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "APK & Google Play Ready",
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "APK / AAB Download & Play Store",
                    style = MaterialTheme.typography.titleLarge
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "APK / AAB File Kaise Download Karein:",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "1. Screen ke top-right corner me AI Studio ke 'Settings (⚙️) / Export' menu par click karein.\n" +
                                "2. Direct phone/tablet me install karne ke liye 'Generate / Download APK' chunein.\n" +
                                "3. Google Play Store par upload karne ke liye 'Generate / Download AAB (Android App Bundle)' chunein.\n" +
                                "4. Google Play Console (play.google.com/console) me 'Create App' karke downloaded file upload kar dein.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                PlayStoreCheckItem("Unique Application ID", "com.aistudio.storeflow.kxpqmr")
                PlayStoreCheckItem("Version Name & Code", "v1.0.0 (Code 1)")
                PlayStoreCheckItem("Target SDK & 64-bit Ready", "Android API 36 (Min SDK 24)")
                PlayStoreCheckItem("Custom Adaptive Icon", "Vector + Mipmap PNGs Ready")
                PlayStoreCheckItem("Tablet & Mobile Adaptive Layout", "NavigationRail + Split-Pane Ready")
                PlayStoreCheckItem("Zero Dangerous Permissions", "Privacy-safe local SQLite storage")

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        clipboard?.setPrimaryClip(ClipData.newPlainText("Play Store Listing", storeListingText))
                        copiedListing = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("copy_play_store_listing_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy Store Listing",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(if (copiedListing) "Copied Play Store Listing!" else "Copy Play Store Description")
                }

                OutlinedButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        clipboard?.setPrimaryClip(ClipData.newPlainText("Privacy Policy", privacyPolicyText))
                        copiedPrivacy = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("copy_privacy_policy_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy Privacy Policy",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(if (copiedPrivacy) "Copied Privacy Policy Text!" else "Copy Privacy Policy Text")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun PlayStoreCheckItem(title: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Verified",
                tint = StatusHealthyGreen,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold
            )
        }
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary
        )
    }
}
