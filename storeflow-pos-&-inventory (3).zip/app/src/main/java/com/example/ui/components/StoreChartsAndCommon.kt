package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSecondary
import com.example.ui.theme.StatusCriticalRed
import com.example.ui.theme.StatusHealthyGreen
import com.example.ui.theme.StatusInfoBlue
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.viewmodel.CategorySalesSlice
import com.example.ui.viewmodel.DailyChartPoint
import java.text.NumberFormat
import java.util.Locale

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class CurrencyOption(
    val symbol: String,
    val code: String,
    val label: String
)

val SUPPORTED_CURRENCIES = listOf(
    CurrencyOption("₹", "INR", "₹ INR (Indian Rupee)"),
    CurrencyOption("৳", "BDT", "৳ BDT (Bangladeshi Taka)"),
    CurrencyOption("$", "USD", "$ USD (US Dollar)"),
    CurrencyOption("€", "EUR", "€ EUR (Euro)"),
    CurrencyOption("£", "GBP", "£ GBP (British Pound)"),
    CurrencyOption("AED ", "AED", "AED (UAE Dirham)"),
    CurrencyOption("SAR ", "SAR", "SAR (Saudi Riyal)"),
    CurrencyOption("RM", "MYR", "RM MYR (Malaysian Ringgit)"),
    CurrencyOption("Rs", "PKR", "Rs (PKR / NPR)")
)

var activeCurrencySymbol by mutableStateOf("₹")
var activeCurrencyCode by mutableStateOf("INR")

fun formatInr(amount: Double, symbol: String = activeCurrencySymbol): String {
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    formatter.maximumFractionDigits = 0
    return "$symbol${formatter.format(amount.toLong())}"
}

@Composable
fun StoreTopAppBar(
    storeName: String,
    currencySymbol: String = activeCurrencySymbol,
    currencyCode: String = activeCurrencyCode,
    pinStatusText: String = "PIN: Default",
    isExpandedTablet: Boolean,
    strictOfflineMode: Boolean,
    lowStockCount: Int,
    onOpenOfflineCenter: () -> Unit,
    onOpenStoreSettings: () -> Unit,
    onLockAppNow: () -> Unit,
    onLowStockClick: () -> Unit,
    onQuickChangeCurrency: () -> Unit = onOpenStoreSettings
) {
    Surface(
        color = Color(0xFF3730A3),
        tonalElevation = 4.dp,
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: StoreFlow App Logo + Single-line Store Name
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_storeflow_logo),
                    contentDescription = "StoreFlow App Logo",
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onOpenStoreSettings)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = storeName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$pinStatusText • $currencySymbol ($currencyCode)",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFFDE047),
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Right: Compact Action Pills & Icons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                // Multi-Currency Quick Selector Chip
                Surface(
                    color = Color(0xFFFEF08A),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = onQuickChangeCurrency)
                        .testTag("top_currency_selector_chip")
                ) {
                    Text(
                        text = "${currencySymbol.trim()} $currencyCode",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF713F12),
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                if (lowStockCount > 0) {
                    Surface(
                        color = Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable(onClick = onLowStockClick)
                            .testTag("top_low_stock_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = "Low Stock Warning",
                                tint = Color(0xFFB91C1C),
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "$lowStockCount",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFB91C1C),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Offline Mode Compact Pill
                Surface(
                    color = Color(0xFFD1FAE5),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = onOpenOfflineCenter)
                        .testTag("offline_mode_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = if (strictOfflineMode) Icons.Default.CloudOff else Icons.Default.CloudDone,
                            contentDescription = "Offline SQLite Status",
                            tint = Color(0xFF065F46),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Offline",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF065F46),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // PIN Lock Button
                IconButton(
                    onClick = onLockAppNow,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("lock_app_pin_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock App with PIN",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Store Settings Button
                IconButton(
                    onClick = onOpenStoreSettings,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("store_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Store Settings",
                        tint = Color(0xFFFDE047),
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun RevenueProfitBarChart(
    points: List<DailyChartPoint>,
    modifier: Modifier = Modifier
) {
    val maxVal = points.maxOfOrNull { it.revenue }?.coerceAtLeast(1000.0) ?: 1000.0
    val primaryColor = EmeraldPrimary
    val profitColor = AmberAccent
    val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "7-Day Revenue vs Profit Trend",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Daily store performance (100% offline SQLite calculation)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendDot(color = primaryColor, label = "Revenue")
                    LegendDot(color = profitColor, label = "Profit")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(165.dp)
            ) {
                val canvasW = size.width
                val canvasH = size.height
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)

                listOf(0.2f, 0.55f, 0.9f).forEach { ratio ->
                    val y = canvasH * ratio
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(canvasW, y),
                        strokeWidth = 1.5f,
                        pathEffect = dashEffect
                    )
                }

                if (points.isNotEmpty()) {
                    val slotWidth = canvasW / points.size
                    val barWidth = (slotWidth * 0.28f).coerceAtMost(28f)

                    points.forEachIndexed { index, pt ->
                        val centerX = slotWidth * index + slotWidth / 2f
                        val revHeight = ((pt.revenue / maxVal).toFloat() * (canvasH * 0.85f)).coerceAtLeast(6f)
                        val profHeight = ((pt.profit / maxVal).toFloat() * (canvasH * 0.85f)).coerceAtLeast(4f)

                        drawRoundRect(
                            color = primaryColor,
                            topLeft = Offset(centerX - barWidth - 2f, canvasH - revHeight),
                            size = Size(barWidth, revHeight),
                            cornerRadius = CornerRadius(8f, 8f)
                        )

                        drawRoundRect(
                            color = profitColor,
                            topLeft = Offset(centerX + 2f, canvasH - profHeight),
                            size = Size(barWidth, profHeight),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                points.forEach { pt ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = pt.dayLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = if (pt.revenue >= 1000) "$activeCurrencySymbol${String.format(Locale.US, "%.1fk", pt.revenue / 1000.0)}" else "$activeCurrencySymbol${pt.revenue.toInt()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun CategoryBreakdownCard(
    slices: List<CategorySalesSlice>,
    modifier: Modifier = Modifier
) {
    val palette = listOf(
        EmeraldPrimary,
        AmberAccent,
        StatusInfoBlue,
        EmeraldSecondary,
        StatusWarningAmber
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Sales by Product Category",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Revenue share across store departments",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (slices.isEmpty()) {
                Text(
                    text = "No sales recorded for the selected period.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                slices.forEachIndexed { idx, slice ->
                    val barColor = palette[idx % palette.size]
                    Column(modifier = Modifier.padding(vertical = 5.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(barColor)
                                )
                                Text(
                                    text = slice.category,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = "${formatInr(slice.revenue)} (${slice.percentage.toInt()}%)",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth((slice.percentage / 100f).coerceIn(0.04f, 1f))
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(barColor)
                            )
                        }
                    }
                }
            }
        }
    }
}
