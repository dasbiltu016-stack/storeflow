package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.CustomerDueEntity
import com.example.data.local.DueTransactionEntity
import com.example.data.local.StoreSettingsEntity
import com.example.ui.components.activeCurrencySymbol
import com.example.ui.components.formatInr
import com.example.ui.components.shareTextReport
import com.example.ui.theme.StatusCriticalRed
import com.example.ui.theme.StatusHealthyGreen
import com.example.ui.theme.StatusInfoBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CustomerDueScreen(
    isExpandedTablet: Boolean,
    customers: List<CustomerDueEntity>,
    dueTransactions: List<DueTransactionEntity>,
    storeSettings: StoreSettingsEntity,
    searchQuery: String,
    showOnlyPendingDues: Boolean,
    selectedCustomerId: Long?,
    onSearchQueryChange: (String) -> Unit,
    onTogglePendingFilter: (Boolean) -> Unit,
    onSelectCustomer: (Long?) -> Unit,
    onSaveCustomer: (CustomerDueEntity) -> Unit,
    onAddCredit: (CustomerDueEntity, Double, String) -> Unit,
    onRecordPayment: (CustomerDueEntity, Double, String, String) -> Unit,
    onDeleteCustomer: (CustomerDueEntity) -> Unit
) {
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showRecordPaymentDialog by remember { mutableStateOf(false) }
    var showGiveCreditDialog by remember { mutableStateOf(false) }
    var showMobileCustomerDetailDialog by remember { mutableStateOf(false) }

    val filteredCustomers = remember(customers, searchQuery, showOnlyPendingDues) {
        customers.filter { cust ->
            val matchesQuery = searchQuery.isBlank() ||
                cust.customerName.contains(searchQuery, ignoreCase = true) ||
                cust.phone.contains(searchQuery, ignoreCase = true) ||
                cust.address.contains(searchQuery, ignoreCase = true)
            val matchesPending = !showOnlyPendingDues || cust.dueBalance > 0.0
            matchesQuery && matchesPending
        }
    }

    val activeCustomer = remember(customers, selectedCustomerId) {
        customers.find { it.id == selectedCustomerId } ?: customers.firstOrNull()
    }

    val totalMarketDue = remember(customers) { customers.sumOf { it.dueBalance } }
    val totalCollected = remember(customers) { customers.sumOf { it.totalPaidAmount } }
    val pendingCustomersCount = remember(customers) { customers.count { it.dueBalance > 0 } }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Khata Summary + Search Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // KPI Strip for Customer Due (Khata)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DueSummaryCard(
                        title = "Total Pending Due",
                        value = formatInr(totalMarketDue),
                        subtitle = "$pendingCustomersCount customers pending",
                        color = if (totalMarketDue > 0) StatusCriticalRed else StatusHealthyGreen,
                        modifier = Modifier.weight(1f)
                    )
                    DueSummaryCard(
                        title = "Total Recovered",
                        value = formatInr(totalCollected),
                        subtitle = "${customers.size} Due accounts",
                        color = StatusHealthyGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search customer name or phone…") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Customer Due") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("customer_due_search_input")
                    )

                    Button(
                        onClick = { showAddCustomerDialog = true },
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                        modifier = Modifier.testTag("add_customer_due_button")
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Add Customer")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Due", fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = !showOnlyPendingDues,
                        onClick = { onTogglePendingFilter(false) },
                        label = { Text("All Accounts (${customers.size})") },
                        modifier = Modifier.testTag("due_filter_all")
                    )
                    FilterChip(
                        selected = showOnlyPendingDues,
                        onClick = { onTogglePendingFilter(true) },
                        label = { Text("Pending Due ($pendingCustomersCount)") },
                        modifier = Modifier.testTag("due_filter_pending")
                    )
                }
            }
        }

        if (isExpandedTablet) {
            // Canonical Tablet Split-Pane Customer Khata List + Detail Ledger
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .weight(1.05f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredCustomers, key = { it.id }) { customer ->
                        CustomerDueRowCard(
                            customer = customer,
                            isSelected = activeCustomer?.id == customer.id,
                            onClick = { onSelectCustomer(customer.id) },
                            onCollectDueClick = {
                                onSelectCustomer(customer.id)
                                showRecordPaymentDialog = true
                            },
                            onAddCreditClick = {
                                onSelectCustomer(customer.id)
                                showGiveCreditDialog = true
                            }
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(0.95f)
                        .fillMaxHeight()
                ) {
                    if (activeCustomer != null) {
                        CustomerLedgerDetailPanel(
                            customer = activeCustomer,
                            storeSettings = storeSettings,
                            transactions = dueTransactions.filter { it.customerId == activeCustomer.id },
                            onCollectPayment = { showRecordPaymentDialog = true },
                            onAddCredit = { showGiveCreditDialog = true },
                            onDeleteCustomer = { onDeleteCustomer(activeCustomer) }
                        )
                    }
                }
            }
        } else {
            // Mobile List View + Ledger Modal
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredCustomers, key = { it.id }) { customer ->
                    CustomerDueRowCard(
                        customer = customer,
                        isSelected = false,
                        onClick = {
                            onSelectCustomer(customer.id)
                            showMobileCustomerDetailDialog = true
                        },
                        onCollectDueClick = {
                            onSelectCustomer(customer.id)
                            showRecordPaymentDialog = true
                        },
                        onAddCreditClick = {
                            onSelectCustomer(customer.id)
                            showGiveCreditDialog = true
                        }
                    )
                }
            }
        }
    }

    if (!isExpandedTablet && showMobileCustomerDetailDialog && activeCustomer != null) {
        AlertDialog(
            onDismissRequest = { showMobileCustomerDetailDialog = false },
            text = {
                CustomerLedgerDetailPanel(
                    customer = activeCustomer,
                    storeSettings = storeSettings,
                    transactions = dueTransactions.filter { it.customerId == activeCustomer.id },
                    onCollectPayment = {
                        showMobileCustomerDetailDialog = false
                        showRecordPaymentDialog = true
                    },
                    onAddCredit = {
                        showMobileCustomerDetailDialog = false
                        showGiveCreditDialog = true
                    },
                    onDeleteCustomer = {
                        showMobileCustomerDetailDialog = false
                        onDeleteCustomer(activeCustomer)
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = { showMobileCustomerDetailDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showAddCustomerDialog) {
        AddCustomerDueDialog(
            onDismiss = { showAddCustomerDialog = false },
            onConfirm = { newCustomer ->
                onSaveCustomer(newCustomer)
                showAddCustomerDialog = false
            }
        )
    }

    if (showRecordPaymentDialog && activeCustomer != null) {
        RecordDuePaymentDialog(
            customer = activeCustomer,
            onDismiss = { showRecordPaymentDialog = false },
            onConfirm = { amount, mode, note ->
                onRecordPayment(activeCustomer, amount, mode, note)
                showRecordPaymentDialog = false
            }
        )
    }

    if (showGiveCreditDialog && activeCustomer != null) {
        AddCreditDueDialog(
            customer = activeCustomer,
            onDismiss = { showGiveCreditDialog = false },
            onConfirm = { amount, note ->
                onAddCredit(activeCustomer, amount, note)
                showGiveCreditDialog = false
            }
        )
    }
}

@Composable
private fun DueSummaryCard(
    title: String,
    value: String,
    subtitle: String,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CustomerDueRowCard(
    customer: CustomerDueEntity,
    isSelected: Boolean,
    onClick: () -> Unit,
    onCollectDueClick: () -> Unit,
    onAddCreditClick: () -> Unit
) {
    val hasDue = customer.dueBalance > 0.0
    val statusColor = if (hasDue) StatusCriticalRed else StatusHealthyGreen

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("customer_due_card_${customer.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = customer.customerName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${customer.phone} • ${customer.address}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = customer.lastTransactionNote,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (hasDue) "Due: ${formatInr(customer.dueBalance)}" else "Settled ${formatInr(0.0)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                    Text(
                        text = "Paid: ${formatInr(customer.totalPaidAmount)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = statusColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (hasDue) customer.dueDateNote else "All Dues Cleared",
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onAddCreditClick,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("give_credit_btn_${customer.id}")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Due", modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Add Due", style = MaterialTheme.typography.labelMedium)
                    }
                    if (hasDue) {
                        FilledTonalButton(
                            onClick = onCollectDueClick,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("collect_due_btn_${customer.id}")
                        ) {
                            Icon(Icons.Default.Payments, contentDescription = "Collect Payment", modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Receive", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerLedgerDetailPanel(
    customer: CustomerDueEntity,
    storeSettings: StoreSettingsEntity,
    transactions: List<DueTransactionEntity>,
    onCollectPayment: () -> Unit,
    onAddCredit: () -> Unit,
    onDeleteCustomer: () -> Unit
) {
    val context = LocalContext.current
    val hasDue = customer.dueBalance > 0.0

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "CUSTOMER DUE LEDGER",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = customer.customerName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${customer.phone} • ${customer.address}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDeleteCustomer) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete Customer Account",
                        tint = StatusCriticalRed
                    )
                }
            }

            // Balance Breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DueSummaryCard(
                    title = "Pending Balance",
                    value = formatInr(customer.dueBalance),
                    subtitle = customer.dueDateNote,
                    color = if (hasDue) StatusCriticalRed else StatusHealthyGreen,
                    modifier = Modifier.weight(1f)
                )
                DueSummaryCard(
                    title = "Total Paid",
                    value = formatInr(customer.totalPaidAmount),
                    subtitle = "Credit: ${formatInr(customer.totalCreditGiven)}",
                    color = StatusInfoBlue,
                    modifier = Modifier.weight(1f)
                )
            }

            // Action Buttons: Collect Payment, Give Credit, Call, WhatsApp Reminder
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onCollectPayment,
                    enabled = hasDue,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("detail_collect_due_button")
                ) {
                    Icon(Icons.Default.Payments, contentDescription = "Collect Payment", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Settle / Receive")
                }

                OutlinedButton(
                    onClick = onAddCredit,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("detail_add_credit_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Due", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Due")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.phone}")))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Call, contentDescription = "Call Customer", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call")
                }

                FilledTonalButton(
                    onClick = {
                        val reminderMsg = """
                            Namaste ${customer.customerName},
                            Friendly reminder from ${storeSettings.storeName}:
                            Your current Due balance is ${formatInr(customer.dueBalance)}.
                            Last entry: ${customer.lastTransactionNote}
                            You can pay easily via UPI: ${storeSettings.upiId}
                            Contact: ${storeSettings.storePhone}
                            Thank you!
                        """.trimIndent()
                        shareTextReport(
                            context = context,
                            subject = "Payment Reminder - ${storeSettings.storeName}",
                            body = reminderMsg
                        )
                    },
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("send_due_reminder_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Send Payment Reminder", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Send Reminder")
                }
            }

            HorizontalDivider()

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = "Ledger History",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Due Transaction History (${transactions.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            if (transactions.isEmpty()) {
                Text(
                    text = "No transactions recorded for this customer yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                transactions.forEach { tx ->
                    val isPayment = tx.type == "PAYMENT_RECEIVED"
                    val dateStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date(tx.timestamp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tx.note,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "$dateStr • ${tx.paymentMode}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = if (isPayment) "-${formatInr(tx.amount)} (Paid)" else "+${formatInr(tx.amount)} (Due)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isPayment) StatusHealthyGreen else StatusCriticalRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddCustomerDueDialog(
    onDismiss: () -> Unit,
    onConfirm: (CustomerDueEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+91 98") }
    var address by remember { mutableStateOf("") }
    var openingDue by remember { mutableStateOf("500") }
    var note by remember { mutableStateOf("Opening Due Credit") }
    var dueDateNote by remember { mutableStateOf("Monthly Due") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Customer Due Account") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Customer Full Name *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_customer_name_input")
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Mobile Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address / Area") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = openingDue,
                        onValueChange = { openingDue = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Opening Due (${activeCurrencySymbol.trim()})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = dueDateNote,
                        onValueChange = { dueDateNote = it },
                        label = { Text("Cycle / Due Term") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Items / Credit Note") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val dueAmt = openingDue.toDoubleOrNull() ?: 0.0
                        onConfirm(
                            CustomerDueEntity(
                                customerName = name.trim(),
                                phone = phone.trim(),
                                address = address.ifBlank { "Local Area" },
                                totalCreditGiven = dueAmt,
                                totalPaidAmount = 0.0,
                                dueBalance = dueAmt,
                                lastTransactionNote = note.ifBlank { "Opening Due Balance" },
                                dueDateNote = dueDateNote.ifBlank { "Monthly Due" }
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("confirm_save_customer_due")
            ) {
                Text("Save Account")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun RecordDuePaymentDialog(
    customer: CustomerDueEntity,
    onDismiss: () -> Unit,
    onConfirm: (Double, String, String) -> Unit
) {
    var amountInput by remember { mutableStateOf(customer.dueBalance.toInt().toString()) }
    var paymentMode by remember { mutableStateOf("UPI") }
    var note by remember { mutableStateOf("Due payment received") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Receive Payment • ${customer.customerName}") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Current Pending Due: ${formatInr(customer.dueBalance)}",
                    style = MaterialTheme.typography.titleSmall,
                    color = StatusCriticalRed,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Amount Received (${activeCurrencySymbol.trim()})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_receive_payment_amount")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("UPI", "Cash", "Card").forEach { mode ->
                        FilterChip(
                            selected = paymentMode == mode,
                            onClick = { paymentMode = mode },
                            label = { Text(mode) }
                        )
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Payment Note / Reference") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onConfirm(amt, paymentMode, note.ifBlank { "Payment via $paymentMode" })
                    }
                },
                modifier = Modifier.testTag("confirm_receive_due_payment")
            ) {
                Text("Record Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun AddCreditDueDialog(
    customer: CustomerDueEntity,
    onDismiss: () -> Unit,
    onConfirm: (Double, String) -> Unit
) {
    var amountInput by remember { mutableStateOf("500") }
    var note by remember { mutableStateOf("Monthly grocery credit") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Due / Credit • ${customer.customerName}") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Existing Due: ${formatInr(customer.dueBalance)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Credit Amount to Add (${activeCurrencySymbol.trim()})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Items / Bill Description") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onConfirm(amt, note.ifBlank { "Credit sale entry" })
                    }
                }
            ) {
                Text("Add to Due")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
