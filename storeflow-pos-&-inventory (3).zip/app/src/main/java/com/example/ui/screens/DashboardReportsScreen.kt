package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.CustomerDueEntity
import com.example.data.local.ProductEntity
import com.example.data.local.PurchaseOrderEntity
import com.example.data.local.SaleRecordEntity
import com.example.data.local.StoreSettingsEntity
import com.example.ui.components.AdMobTestNativeAdCard
import com.example.ui.components.CategoryBreakdownCard
import com.example.ui.components.RevenueProfitBarChart
import com.example.ui.components.formatInr
import com.example.ui.components.shareTextReport
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.StatusCriticalRed
import com.example.ui.theme.StatusHealthyGreen
import com.example.ui.theme.StatusInfoBlue
import com.example.ui.viewmodel.CategorySalesSlice
import com.example.ui.viewmodel.DailyChartPoint
import com.example.ui.viewmodel.ReportPeriod
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardReportsScreen(
    isExpandedTablet: Boolean,
    storeSettings: StoreSettingsEntity,
    products: List<ProductEntity>,
    sales: List<SaleRecordEntity>,
    purchaseOrders: List<PurchaseOrderEntity>,
    customerDues: List<CustomerDueEntity>,
    selectedPeriod: ReportPeriod,
    dailyChartPoints: List<DailyChartPoint>,
    categorySlices: List<CategorySalesSlice>,
    onSelectPeriod: (ReportPeriod) -> Unit,
    onQuickRestockProduct: (ProductEntity) -> Unit,
    onNavigateToPos: () -> Unit,
    onNavigateToInventory: () -> Unit,
    onNavigateToCustomerDue: () -> Unit,
    onOpenStoreSettings: () -> Unit,
    onExportCsvReport: () -> Unit
) {
    val context = LocalContext.current
    val now = System.currentTimeMillis()
    val filteredSales = remember(sales, selectedPeriod) {
        when (selectedPeriod) {
            ReportPeriod.ALL_TIME -> sales
            ReportPeriod.LAST_7_DAYS -> sales.filter { it.timestamp >= now - 7 * 86_400_000L }
            ReportPeriod.TODAY -> sales.filter { it.timestamp >= now - 86_400_000L }
        }
    }

    val totalRevenue = filteredSales.sumOf { it.totalAmount }
    val totalProfit = filteredSales.sumOf { it.totalProfit }
    val profitMarginPct = if (totalRevenue > 0) (totalProfit / totalRevenue) * 100.0 else 0.0
    val totalInventoryValue = products.sumOf { it.stockValueAtCost }
    val lowStockProducts = products.filter { it.isLowStock || it.isOutOfStock }
    val pendingPoCount = purchaseOrders.count { it.status == "PENDING" }
    val totalMarketDue = customerDues.sumOf { it.dueBalance }
    val pendingDueCustomersCount = customerDues.count { it.dueBalance > 0 }

    val paymentBreakdown = remember(filteredSales) {
        filteredSales.groupBy { it.paymentMethod }
            .mapValues { (_, list) -> list.sumOf { it.totalAmount } }
    }

    if (isExpandedTablet) {
        // Canonical Tablet Split-Pane Dashboard & Sales Reports
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1.15f)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                item {
                    HeroStoreBannerCard(
                        storeSettings = storeSettings,
                        onNavigateToPos = onNavigateToPos,
                        onNavigateToCustomerDue = onNavigateToCustomerDue,
                        onOpenStoreSettings = onOpenStoreSettings,
                        onExportCsvReport = onExportCsvReport
                    )
                }
                item {
                    PeriodFilterRow(
                        selectedPeriod = selectedPeriod,
                        onSelectPeriod = onSelectPeriod,
                        onExportCsvReport = onExportCsvReport
                    )
                }
                item {
                    KpiMetricsGrid(
                        totalRevenue = totalRevenue,
                        totalProfit = totalProfit,
                        profitMarginPct = profitMarginPct,
                        invoicesCount = filteredSales.size,
                        inventoryValue = totalInventoryValue,
                        totalMarketDue = totalMarketDue,
                        pendingDueCustomersCount = pendingDueCustomersCount,
                        lowStockCount = lowStockProducts.size,
                        pendingPoCount = pendingPoCount,
                        onNavigateToCustomerDue = onNavigateToCustomerDue
                    )
                }
                item {
                    RevenueProfitBarChart(points = dailyChartPoints)
                }
                item {
                    CategoryBreakdownCard(slices = categorySlices)
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(0.85f)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                item {
                    PaymentMethodsBreakdownCard(paymentBreakdown = paymentBreakdown)
                }
                if (storeSettings.enableLowStockBanner && lowStockProducts.isNotEmpty()) {
                    item {
                        LowStockAlertsCard(
                            lowStockProducts = lowStockProducts,
                            onQuickRestockProduct = onQuickRestockProduct,
                            onViewAllInventory = onNavigateToInventory
                        )
                    }
                }
                item {
                    Text(
                        text = "Recent Sales Invoices (${filteredSales.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(filteredSales.take(10), key = { it.id }) { sale ->
                    SaleInvoiceRowCard(
                        sale = sale,
                        onShareInvoice = {
                            shareTextReport(
                                context = context,
                                subject = "Invoice ${sale.invoiceNumber} - ${storeSettings.storeName}",
                                body = "${storeSettings.storeName}\n${storeSettings.storeAddress}\nGSTIN: ${storeSettings.gstNumber}\nReceipt: ${sale.invoiceNumber}\nCustomer: ${sale.customerName}\nItems: ${sale.itemsSummary}\nTotal Paid: ${formatInr(sale.totalAmount)} (${sale.paymentMethod})\n${storeSettings.receiptFooterNote}"
                            )
                        }
                    )
                }
            }
        }
    } else {
        // Compact Mobile Single-Column Layout
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                HeroStoreBannerCard(
                    storeSettings = storeSettings,
                    onNavigateToPos = onNavigateToPos,
                    onNavigateToCustomerDue = onNavigateToCustomerDue,
                    onOpenStoreSettings = onOpenStoreSettings,
                    onExportCsvReport = onExportCsvReport
                )
            }
            item {
                PeriodFilterRow(
                    selectedPeriod = selectedPeriod,
                    onSelectPeriod = onSelectPeriod,
                    onExportCsvReport = onExportCsvReport
                )
            }
            item {
                KpiMetricsGrid(
                    totalRevenue = totalRevenue,
                    totalProfit = totalProfit,
                    profitMarginPct = profitMarginPct,
                    invoicesCount = filteredSales.size,
                    inventoryValue = totalInventoryValue,
                    totalMarketDue = totalMarketDue,
                    pendingDueCustomersCount = pendingDueCustomersCount,
                    lowStockCount = lowStockProducts.size,
                    pendingPoCount = pendingPoCount,
                    onNavigateToCustomerDue = onNavigateToCustomerDue
                )
            }
            if (storeSettings.enableLowStockBanner && lowStockProducts.isNotEmpty()) {
                item {
                    LowStockAlertsCard(
                        lowStockProducts = lowStockProducts,
                        onQuickRestockProduct = onQuickRestockProduct,
                        onViewAllInventory = onNavigateToInventory
                    )
                }
            }
            item {
                RevenueProfitBarChart(points = dailyChartPoints)
            }
            item {
                CategoryBreakdownCard(slices = categorySlices)
            }
            item {
                PaymentMethodsBreakdownCard(paymentBreakdown = paymentBreakdown)
            }
            item {
                Text(
                    text = "Recent Sales Invoices (${filteredSales.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(filteredSales.take(8), key = { it.id }) { sale ->
                SaleInvoiceRowCard(
                    sale = sale,
                    onShareInvoice = {
                        shareTextReport(
                            context = context,
                            subject = "Invoice ${sale.invoiceNumber} - ${storeSettings.storeName}",
                            body = "${storeSettings.storeName}\n${storeSettings.storeAddress}\nGSTIN: ${storeSettings.gstNumber}\nReceipt: ${sale.invoiceNumber}\nCustomer: ${sale.customerName}\nItems: ${sale.itemsSummary}\nTotal Paid: ${formatInr(sale.totalAmount)} (${sale.paymentMethod})\n${storeSettings.receiptFooterNote}"
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun HeroStoreBannerCard(
    storeSettings: StoreSettingsEntity,
    onNavigateToPos: () -> Unit,
    onNavigateToCustomerDue: () -> Unit,
    onOpenStoreSettings: () -> Unit,
    onExportCsvReport: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.ic_store_hero_banner),
                contentDescription = "StoreFlow overview illustration",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(108.dp)
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isCustomPinSaved = storeSettings.isPinLockEnabled || storeSettings.appPinCode != "1234"
                val pinStatusLabel = if (isCustomPinSaved) {
                    "PIN: ${storeSettings.appPinCode}"
                } else {
                    "PIN: Default (1234)"
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_storeflow_logo),
                            contentDescription = "StoreFlow Logo",
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = storeSettings.storeName,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${storeSettings.ownerName} • $pinStatusLabel • ${storeSettings.currencySymbol.trim()} (${storeSettings.currencyCode})",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFFDE047),
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    IconButton(
                        onClick = onExportCsvReport,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.22f))
                            .size(32.dp)
                            .testTag("hero_export_report_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Store Report",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onNavigateToPos,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF59E0B),
                            contentColor = Color(0xFF1F1300)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("hero_new_sale_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PointOfSale,
                            contentDescription = "New POS Sale",
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New POS Bill", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }

                    FilledTonalButton(
                        onClick = onNavigateToCustomerDue,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("hero_customer_due_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "Customer Due",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Customer Due", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    }

                    FilledTonalButton(
                        onClick = onOpenStoreSettings,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("hero_store_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Store Settings",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isCustomPinSaved) "PIN: ${storeSettings.appPinCode}" else "PIN: Default",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PeriodFilterRow(
    selectedPeriod: ReportPeriod,
    onSelectPeriod: (ReportPeriod) -> Unit,
    onExportCsvReport: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ReportPeriod.entries.forEach { period ->
                FilterChip(
                    selected = selectedPeriod == period,
                    onClick = { onSelectPeriod(period) },
                    label = { Text(period.label) },
                    modifier = Modifier.testTag("period_chip_${period.name.lowercase()}")
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        FilledTonalButton(
            onClick = onExportCsvReport,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.testTag("export_sales_report_button")
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Export CSV",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Export CSV", style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun KpiMetricsGrid(
    totalRevenue: Double,
    totalProfit: Double,
    profitMarginPct: Double,
    invoicesCount: Int,
    inventoryValue: Double,
    totalMarketDue: Double,
    pendingDueCustomersCount: Int,
    lowStockCount: Int,
    pendingPoCount: Int,
    onNavigateToCustomerDue: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            KpiStatCard(
                title = "Total Sales Revenue",
                value = formatInr(totalRevenue),
                subtitle = "$invoicesCount customer invoices",
                accentColor = EmeraldPrimary,
                modifier = Modifier.weight(1f)
            )
            KpiStatCard(
                title = "Net Store Profit",
                value = formatInr(totalProfit),
                subtitle = "${String.format(Locale.US, "%.1f", profitMarginPct)}% net margin",
                accentColor = StatusHealthyGreen,
                modifier = Modifier.weight(1f)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            KpiStatCard(
                title = "Customer Due",
                value = formatInr(totalMarketDue),
                subtitle = "$pendingDueCustomersCount customers • Tap to collect",
                accentColor = if (totalMarketDue > 0) StatusCriticalRed else StatusHealthyGreen,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onNavigateToCustomerDue)
                    .testTag("kpi_customer_due_card")
            )
            KpiStatCard(
                title = "Stock & Restock Alerts",
                value = "$lowStockCount Low SKUs",
                subtitle = "${formatInr(inventoryValue)} stock • $pendingPoCount POs",
                accentColor = if (lowStockCount > 0) AmberAccent else StatusInfoBlue,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun KpiStatCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(accentColor)
            )
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(accentColor)
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineSmall,
                    color = accentColor,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun LowStockAlertsCard(
    lowStockProducts: List<ProductEntity>,
    onQuickRestockProduct: (ProductEntity) -> Unit,
    onViewAllInventory: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = StatusCriticalRed.copy(alpha = 0.08f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = "Low Stock",
                        tint = StatusCriticalRed
                    )
                    Column {
                        Text(
                            text = "Low Stock Reorder Queue (${lowStockProducts.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = StatusCriticalRed,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Items below minimum threshold — tap +15 to restock instantly",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            lowStockProducts.take(4).forEach { prod ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = prod.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Stock: ${prod.stockQty} ${prod.unit} (Min: ${prod.minStockLevel}) • ${prod.supplierName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusCriticalRed
                            )
                        }
                        FilledTonalButton(
                            onClick = { onQuickRestockProduct(prod) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("quick_restock_${prod.id}")
                        ) {
                            Text("+15 Stock", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentMethodsBreakdownCard(
    paymentBreakdown: Map<String, Double>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Payments,
                    contentDescription = "Payment Channels",
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Collections by Payment Mode",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("UPI", "Cash", "Card", "Due / Credit").forEach { mode ->
                    val amount = paymentBreakdown[mode] ?: 0.0
                    Surface(
                        modifier = Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = mode.substringBefore(" "),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = formatInr(amount),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SaleInvoiceRowCard(
    sale: SaleRecordEntity,
    onShareInvoice: () -> Unit
) {
    val dateFormatted = remember(sale.timestamp) {
        SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date(sale.timestamp))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = sale.invoiceNumber,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = sale.paymentMethod,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = dateFormatted,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = sale.customerName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = sale.itemsSummary,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = formatInr(sale.totalAmount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "+${formatInr(sale.totalProfit)} profit",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusHealthyGreen
                )
                IconButton(
                    onClick = onShareInvoice,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share Receipt",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
