package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ProductEntity
import com.example.data.local.StockMovementEntity
import com.example.data.local.SupplierEntity
import com.example.ui.components.activeCurrencySymbol
import com.example.ui.components.formatInr
import com.example.ui.theme.StatusCriticalRed
import com.example.ui.theme.StatusHealthyGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.viewmodel.StockFilter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun InventoryScreen(
    isExpandedTablet: Boolean,
    products: List<ProductEntity>,
    suppliers: List<SupplierEntity>,
    stockMovements: List<StockMovementEntity>,
    searchQuery: String,
    selectedCategory: String,
    stockFilter: StockFilter,
    selectedProductId: Long?,
    onSearchQueryChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onStockFilterChange: (StockFilter) -> Unit,
    onSelectProduct: (Long?) -> Unit,
    onSaveProduct: (ProductEntity) -> Unit,
    onDeleteProduct: (ProductEntity) -> Unit,
    onAdjustStock: (ProductEntity, Int, String) -> Unit,
    onAddToPosCart: (ProductEntity) -> Unit
) {
    var showAddOrEditDialog by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showMobileProductDetailDialog by remember { mutableStateOf(false) }
    var customCategories by remember { mutableStateOf(listOf<String>()) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }

    val availableCategories = remember(products, customCategories) {
        val fromProducts = products.map { it.category.trim() }.filter { it.isNotBlank() }
        (customCategories + fromProducts).distinct()
    }

    val filteredProducts = remember(products, searchQuery, selectedCategory, stockFilter) {
        products.filter { prod ->
            val matchesQuery = searchQuery.isBlank() ||
                prod.name.contains(searchQuery, ignoreCase = true) ||
                prod.sku.contains(searchQuery, ignoreCase = true) ||
                prod.category.contains(searchQuery, ignoreCase = true) ||
                prod.supplierName.contains(searchQuery, ignoreCase = true)
            val matchesCategory = selectedCategory == "All" || prod.category.equals(selectedCategory, ignoreCase = true)
            val matchesStock = when (stockFilter) {
                StockFilter.ALL -> true
                StockFilter.LOW_STOCK -> prod.isLowStock || prod.isOutOfStock
                StockFilter.OUT_OF_STOCK -> prod.isOutOfStock
            }
            matchesQuery && matchesCategory && matchesStock
        }
    }

    val activeProduct = remember(products, selectedProductId) {
        products.find { it.id == selectedProductId } ?: products.firstOrNull()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Search & Filter Controls
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search name, SKU, or supplier…") },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Search Products")
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear Search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("inventory_search_input")
                    )

                    Button(
                        onClick = {
                            editingProduct = null
                            showAddOrEditDialog = true
                        },
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                        modifier = Modifier.testTag("add_product_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Product")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Item", fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = selectedCategory == "All" && stockFilter == StockFilter.ALL,
                        onClick = {
                            onCategoryChange("All")
                            onStockFilterChange(StockFilter.ALL)
                        },
                        label = { Text("All (${products.size})") },
                        modifier = Modifier.testTag("cat_chip_all")
                    )
                    FilterChip(
                        selected = stockFilter == StockFilter.LOW_STOCK,
                        onClick = {
                            onStockFilterChange(
                                if (stockFilter == StockFilter.LOW_STOCK) StockFilter.ALL else StockFilter.LOW_STOCK
                            )
                        },
                        label = { Text("Low Stock") },
                        modifier = Modifier.testTag("low_stock_filter_chip")
                    )
                    FilterChip(
                        selected = false,
                        onClick = { showAddCategoryDialog = true },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Manual Category",
                                modifier = Modifier.size(15.dp)
                            )
                        },
                        label = { Text("Add Category") },
                        modifier = Modifier.testTag("add_custom_category_chip")
                    )
                    customCategories.forEach { category ->
                        FilterChip(
                            selected = selectedCategory.equals(category, ignoreCase = true),
                            onClick = {
                                onCategoryChange(if (selectedCategory.equals(category, ignoreCase = true)) "All" else category)
                            },
                            label = { Text(category) }
                        )
                    }
                }
            }
        }

        if (isExpandedTablet) {
            // Canonical Tablet List-Detail View
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .weight(1.1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    if (filteredProducts.isEmpty()) {
                        item {
                            EmptyInventoryCard(
                                onAddFirstProduct = {
                                    editingProduct = null
                                    showAddOrEditDialog = true
                                }
                            )
                        }
                    } else {
                        items(filteredProducts, key = { it.id }) { product ->
                            ProductInventoryCard(
                                product = product,
                                isSelected = activeProduct?.id == product.id,
                                onClick = { onSelectProduct(product.id) },
                                onQuickIncrement = {
                                    onAdjustStock(product, 5, "Quick +5 stock-in")
                                },
                                onAddToPosCart = { onAddToPosCart(product) }
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(0.9f)
                        .fillMaxHeight()
                ) {
                    if (activeProduct != null) {
                        ProductDetailAndAdjustPanel(
                            product = activeProduct,
                            movements = stockMovements.filter { it.productId == activeProduct.id },
                            onAdjustStock = { delta, note ->
                                onAdjustStock(activeProduct, delta, note)
                            },
                            onEditProduct = {
                                editingProduct = activeProduct
                                showAddOrEditDialog = true
                            },
                            onDeleteProduct = {
                                onDeleteProduct(activeProduct)
                            },
                            onAddToPosCart = {
                                onAddToPosCart(activeProduct)
                            }
                        )
                    }
                }
            }
        } else {
            // Mobile List View + Detail Modal
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (filteredProducts.isEmpty()) {
                    item {
                        EmptyInventoryCard(
                            onAddFirstProduct = {
                                editingProduct = null
                                showAddOrEditDialog = true
                            }
                        )
                    }
                } else {
                    items(filteredProducts, key = { it.id }) { product ->
                        ProductInventoryCard(
                            product = product,
                            isSelected = false,
                            onClick = {
                                onSelectProduct(product.id)
                                showMobileProductDetailDialog = true
                            },
                            onQuickIncrement = {
                                onAdjustStock(product, 5, "Quick +5 stock-in")
                            },
                            onAddToPosCart = { onAddToPosCart(product) }
                        )
                    }
                }
            }
        }
    }

    if (!isExpandedTablet && showMobileProductDetailDialog && activeProduct != null) {
        AlertDialog(
            onDismissRequest = { showMobileProductDetailDialog = false },
            text = {
                ProductDetailAndAdjustPanel(
                    product = activeProduct,
                    movements = stockMovements.filter { it.productId == activeProduct.id },
                    onAdjustStock = { delta, note ->
                        onAdjustStock(activeProduct, delta, note)
                    },
                    onEditProduct = {
                        showMobileProductDetailDialog = false
                        editingProduct = activeProduct
                        showAddOrEditDialog = true
                    },
                    onDeleteProduct = {
                        showMobileProductDetailDialog = false
                        onDeleteProduct(activeProduct)
                    },
                    onAddToPosCart = {
                        onAddToPosCart(activeProduct)
                        showMobileProductDetailDialog = false
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = { showMobileProductDetailDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showAddOrEditDialog) {
        AddOrEditProductDialog(
            initialProduct = editingProduct,
            suppliers = suppliers,
            existingCategories = availableCategories,
            onDismiss = { showAddOrEditDialog = false },
            onConfirm = { savedProduct ->
                if (savedProduct.category.isNotBlank() &&
                    customCategories.none { it.equals(savedProduct.category, ignoreCase = true) }
                ) {
                    customCategories = customCategories + savedProduct.category.trim()
                }
                onSaveProduct(savedProduct)
                showAddOrEditDialog = false
            }
        )
    }

    if (showAddCategoryDialog) {
        var newCatName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddCategoryDialog = false },
            title = { Text("Add Custom Category") },
            text = {
                OutlinedTextField(
                    value = newCatName,
                    onValueChange = { newCatName = it },
                    label = { Text("Type Category Name *") },
                    placeholder = { Text("e.g., Medicine, Clothes, Hardware…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = newCatName.trim()
                        if (trimmed.isNotBlank()) {
                            if (customCategories.none { it.equals(trimmed, ignoreCase = true) }) {
                                customCategories = customCategories + trimmed
                            }
                            onCategoryChange(trimmed)
                            showAddCategoryDialog = false
                        }
                    }
                ) {
                    Text("Add Category")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCategoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ProductInventoryCard(
    product: ProductEntity,
    isSelected: Boolean,
    onClick: () -> Unit,
    onQuickIncrement: () -> Unit,
    onAddToPosCart: () -> Unit
) {
    val statusColor = when {
        product.isOutOfStock -> StatusCriticalRed
        product.isLowStock -> StatusWarningAmber
        else -> StatusHealthyGreen
    }
    val statusLabel = when {
        product.isOutOfStock -> "OUT OF STOCK"
        product.isLowStock -> "LOW STOCK (${product.stockQty} ${product.unit})"
        else -> "${product.stockQty} ${product.unit} in stock"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = product.sku,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = product.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "• ${product.shelfLocation}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Supplier: ${product.supplierName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = formatInr(product.sellingPrice),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Cost: ${formatInr(product.costPrice)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = statusColor.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = statusLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onQuickIncrement,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("quick_add_stock_${product.id}")
                    ) {
                        Text("+5 Stock", style = MaterialTheme.typography.labelMedium)
                    }
                    FilledTonalButton(
                        onClick = onAddToPosCart,
                        enabled = !product.isOutOfStock,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("add_to_pos_${product.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddShoppingCart,
                            contentDescription = "Add to POS Bill",
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sell", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductDetailAndAdjustPanel(
    product: ProductEntity,
    movements: List<StockMovementEntity>,
    onAdjustStock: (Int, String) -> Unit,
    onEditProduct: () -> Unit,
    onDeleteProduct: () -> Unit,
    onAddToPosCart: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${product.sku} • ${product.category}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Location: ${product.shelfLocation} • Supplier: ${product.supplierName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row {
                    IconButton(
                        onClick = onEditProduct,
                        modifier = Modifier.testTag("edit_product_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Product")
                    }
                    IconButton(
                        onClick = onDeleteProduct,
                        modifier = Modifier.testTag("delete_product_button")
                    ) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Delete Product",
                            tint = StatusCriticalRed
                        )
                    }
                }
            }

            // Pricing & Profit Margin Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricBox(
                    label = "Selling Price",
                    value = formatInr(product.sellingPrice),
                    modifier = Modifier.weight(1f)
                )
                MetricBox(
                    label = "Unit Profit",
                    value = "${formatInr(product.unitProfit)} (${product.marginPercent.toInt()}%)",
                    modifier = Modifier.weight(1f)
                )
                MetricBox(
                    label = "Stock Value",
                    value = formatInr(product.stockValueAtCost),
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider()

            // Quick Stock Adjuster Controls
            Text(
                text = "Quick Stock Adjustment (Current: ${product.stockQty} ${product.unit})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onAdjustStock(-1, "Manual -1 adjustment") },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Minus 1", modifier = Modifier.size(16.dp))
                    Text("1")
                }
                OutlinedButton(
                    onClick = { onAdjustStock(1, "Manual +1 adjustment") },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Plus 1", modifier = Modifier.size(16.dp))
                    Text("1")
                }
                FilledTonalButton(
                    onClick = { onAdjustStock(10, "Restock batch +10") },
                    modifier = Modifier.weight(1.2f)
                ) {
                    Text("+10 Restock")
                }
                FilledTonalButton(
                    onClick = { onAdjustStock(25, "Wholesale crate +25") },
                    modifier = Modifier.weight(1.2f)
                ) {
                    Text("+25 Crate")
                }
            }

            Button(
                onClick = onAddToPosCart,
                enabled = !product.isOutOfStock,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = "Add to POS Cart")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add to POS Billing Cart (${formatInr(product.sellingPrice)})")
            }

            HorizontalDivider()

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = "Stock Log",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Recent Stock Movements",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            if (movements.isEmpty()) {
                Text(
                    text = "No stock changes logged for this item yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                movements.take(5).forEach { mov ->
                    val timeFmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date(mov.timestamp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mov.note,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = timeFmt,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = if (mov.changeQty > 0) "+${mov.changeQty}" else "${mov.changeQty}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (mov.changeQty > 0) StatusHealthyGreen else StatusCriticalRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun EmptyInventoryCard(onAddFirstProduct: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Inventory,
                contentDescription = "No Products",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            )
            Text(
                text = "No matching inventory items",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Try clearing your search filter or add a new SKU to your offline catalog.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(onClick = onAddFirstProduct) {
                Icon(Icons.Default.Add, contentDescription = "Add Product")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add New Product")
            }
        }
    }
}

@Composable
private fun AddOrEditProductDialog(
    initialProduct: ProductEntity?,
    suppliers: List<SupplierEntity>,
    existingCategories: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (ProductEntity) -> Unit
) {
    var name by remember { mutableStateOf(initialProduct?.name ?: "") }
    var sku by remember { mutableStateOf(initialProduct?.sku ?: "SKU-${(100..999).random()}") }
    var category by remember { mutableStateOf(initialProduct?.category ?: "") }
    var stockQty by remember { mutableStateOf(initialProduct?.stockQty?.toString() ?: "") }
    var minStock by remember { mutableStateOf(initialProduct?.minStockLevel?.toString() ?: "5") }
    var unit by remember { mutableStateOf(initialProduct?.unit ?: "") }
    var costPrice by remember { mutableStateOf(initialProduct?.costPrice?.toInt()?.toString() ?: "") }
    var sellingPrice by remember { mutableStateOf(initialProduct?.sellingPrice?.toInt()?.toString() ?: "") }
    var shelfLocation by remember { mutableStateOf(initialProduct?.shelfLocation ?: "") }
    var supplierNameInput by remember {
        mutableStateOf(initialProduct?.supplierName ?: "")
    }
    var selectedSupplierId by remember {
        mutableStateOf(initialProduct?.supplierId ?: 1L)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialProduct == null) "Add New Store Product" else "Edit Product Details",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Product Name *") },
                    placeholder = { Text("Enter item name manually…") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_product_name_input")
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category (Type Manually) *") },
                    placeholder = { Text("Type any category (e.g., Medicine, Kirana, Clothes…)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_product_category_input")
                )

                if (existingCategories.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        existingCategories.forEach { cat ->
                            FilterChip(
                                selected = category.equals(cat, ignoreCase = true),
                                onClick = { category = cat },
                                label = { Text(cat) }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("SKU / Code") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unit (Pc/Kg/Box/Pack)") },
                        placeholder = { Text("Pc, Kg, Box…") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stockQty,
                        onValueChange = { stockQty = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Current Stock") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minStock,
                        onValueChange = { minStock = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Low Alert Level") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = costPrice,
                        onValueChange = { costPrice = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Cost Price (${activeCurrencySymbol.trim()})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sellingPrice,
                        onValueChange = { sellingPrice = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Selling Price (${activeCurrencySymbol.trim()})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_selling_price_input")
                    )
                }

                OutlinedTextField(
                    value = shelfLocation,
                    onValueChange = { shelfLocation = it },
                    label = { Text("Rack / Shelf Location") },
                    placeholder = { Text("e.g., Rack 1, Shelf B…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = supplierNameInput,
                    onValueChange = { supplierNameInput = it },
                    label = { Text("Supplier / Vendor Name (Manual)") },
                    placeholder = { Text("Type supplier name or tap below…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (suppliers.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        suppliers.forEach { sup ->
                            FilterChip(
                                selected = supplierNameInput.equals(sup.name, ignoreCase = true),
                                onClick = {
                                    supplierNameInput = sup.name
                                    selectedSupplierId = sup.id
                                },
                                label = { Text(sup.name) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val cost = costPrice.toDoubleOrNull() ?: 0.0
                        val sell = sellingPrice.toDoubleOrNull() ?: cost
                        onConfirm(
                            ProductEntity(
                                id = initialProduct?.id ?: 0L,
                                sku = sku.ifBlank { "SKU-100" },
                                name = name.trim(),
                                category = category.trim().ifBlank { "General" },
                                stockQty = stockQty.toIntOrNull() ?: 0,
                                minStockLevel = minStock.toIntOrNull() ?: 5,
                                unit = unit.trim().ifBlank { "Pc" },
                                costPrice = cost,
                                sellingPrice = sell,
                                supplierId = selectedSupplierId,
                                supplierName = supplierNameInput.trim().ifBlank { "Direct Vendor" },
                                shelfLocation = shelfLocation.trim().ifBlank { "Main Shelf" }
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("save_product_confirm_button")
            ) {
                Text("Save Product")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
