package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCartCheckout
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ProductEntity
import com.example.data.local.SaleRecordEntity
import com.example.data.repository.CartItem
import com.example.ui.components.activeCurrencySymbol
import com.example.ui.components.formatInr
import com.example.ui.components.shareTextReport
import com.example.ui.theme.StatusCriticalRed
import com.example.ui.theme.StatusHealthyGreen

private val PAYMENT_MODES = listOf("UPI", "Cash", "Card", "Due / Credit")

@Composable
fun PosSalesScreen(
    isExpandedTablet: Boolean,
    products: List<ProductEntity>,
    salesHistory: List<SaleRecordEntity>,
    cartItems: List<CartItem>,
    onAddToCart: (ProductEntity) -> Unit,
    onUpdateCartQty: (Long, Int) -> Unit,
    onClearCart: () -> Unit,
    onCompleteCheckout: (String, String, String, Double, (SaleRecordEntity) -> Unit) -> Unit
) {
    val context = LocalContext.current
    var catalogSearch by remember { mutableStateOf("") }
    var mobileTabIndex by remember { mutableIntStateOf(0) } // 0 = Catalog, 1 = Cart, 2 = History
    var lastCompletedInvoice by remember { mutableStateOf<SaleRecordEntity?>(null) }

    val availableProducts = remember(products, catalogSearch) {
        products.filter {
            catalogSearch.isBlank() ||
                it.name.contains(catalogSearch, ignoreCase = true) ||
                it.sku.contains(catalogSearch, ignoreCase = true) ||
                it.category.contains(catalogSearch, ignoreCase = true)
        }
    }

    val totalCartItemsCount = cartItems.sumOf { it.quantity }
    val totalCartAmount = cartItems.sumOf { it.lineTotal }

    if (isExpandedTablet) {
        // Tablet Split-Pane POS Terminal: Left = Product Catalog + Recent Sales, Right = Live Checkout Counter
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1.15f)
                    .fillMaxHeight()
            ) {
                OutlinedTextField(
                    value = catalogSearch,
                    onValueChange = { catalogSearch = it },
                    placeholder = { Text("Scan SKU or search item to add to bill…") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search POS") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pos_search_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    item {
                        Text(
                            text = "Tap Products to Add to Bill (${availableProducts.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(availableProducts, key = { it.id }) { prod ->
                        val qtyInCart = cartItems.find { it.product.id == prod.id }?.quantity ?: 0
                        PosCatalogItemCard(
                            product = prod,
                            qtyInCart = qtyInCart,
                            onAdd = { onAddToCart(prod) },
                            onDecrement = { onUpdateCartQty(prod.id, qtyInCart - 1) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Recent POS Invoices (${salesHistory.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(salesHistory.take(6), key = { "hist_${it.id}" }) { sale ->
                        SaleInvoiceRowCard(
                            sale = sale,
                            onShareInvoice = {
                                shareTextReport(
                                    context = context,
                                    subject = "Invoice ${sale.invoiceNumber}",
                                    body = "StoreFlow Receipt ${sale.invoiceNumber}\nCustomer: ${sale.customerName}\nItems: ${sale.itemsSummary}\nTotal Paid: ${formatInr(sale.totalAmount)} (${sale.paymentMethod})"
                                )
                            }
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .weight(0.85f)
                    .fillMaxHeight()
            ) {
                PosCheckoutPanel(
                    cartItems = cartItems,
                    lastInvoice = lastCompletedInvoice,
                    onUpdateCartQty = onUpdateCartQty,
                    onClearCart = onClearCart,
                    onCheckout = { name, phone, payment, discount ->
                        onCompleteCheckout(name, phone, payment, discount) { record ->
                            lastCompletedInvoice = record
                        }
                    },
                    onShareLastInvoice = { inv ->
                        shareTextReport(
                            context = context,
                            subject = "Invoice ${inv.invoiceNumber}",
                            body = "StoreFlow Receipt ${inv.invoiceNumber}\nCustomer: ${inv.customerName}\nItems: ${inv.itemsSummary}\nTotal Paid: ${formatInr(inv.totalAmount)} (${inv.paymentMethod})"
                        )
                    }
                )
            }
        }
    } else {
        // Mobile POS View with Mode Switcher + Sticky Checkout Footer
        Column(modifier = Modifier.fillMaxSize()) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = mobileTabIndex == 0,
                        onClick = { mobileTabIndex = 0 },
                        label = { Text("POS Catalog") },
                        modifier = Modifier.testTag("pos_tab_catalog")
                    )
                    FilterChip(
                        selected = mobileTabIndex == 1,
                        onClick = { mobileTabIndex = 1 },
                        label = { Text("Cart ($totalCartItemsCount)") },
                        modifier = Modifier.testTag("pos_tab_cart")
                    )
                    FilterChip(
                        selected = mobileTabIndex == 2,
                        onClick = { mobileTabIndex = 2 },
                        label = { Text("Invoices (${salesHistory.size})") },
                        modifier = Modifier.testTag("pos_tab_invoices")
                    )
                }
            }

            when (mobileTabIndex) {
                0 -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        OutlinedTextField(
                            value = catalogSearch,
                            onValueChange = { catalogSearch = it },
                            placeholder = { Text("Search product or SKU…") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search POS") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                                .testTag("pos_search_input")
                        )

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(availableProducts, key = { it.id }) { prod ->
                                val qtyInCart = cartItems.find { it.product.id == prod.id }?.quantity ?: 0
                                PosCatalogItemCard(
                                    product = prod,
                                    qtyInCart = qtyInCart,
                                    onAdd = { onAddToCart(prod) },
                                    onDecrement = { onUpdateCartQty(prod.id, qtyInCart - 1) }
                                )
                            }
                        }

                        if (cartItems.isNotEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                tonalElevation = 4.dp
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "$totalCartItemsCount items in bill",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Text(
                                            text = formatInr(totalCartAmount),
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                    Button(
                                        onClick = { mobileTabIndex = 1 },
                                        modifier = Modifier.testTag("proceed_to_checkout_button")
                                    ) {
                                        Icon(Icons.Default.ShoppingCartCheckout, contentDescription = "Review Bill")
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Review & Bill")
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        PosCheckoutPanel(
                            cartItems = cartItems,
                            lastInvoice = lastCompletedInvoice,
                            onUpdateCartQty = onUpdateCartQty,
                            onClearCart = onClearCart,
                            onCheckout = { name, phone, payment, discount ->
                                onCompleteCheckout(name, phone, payment, discount) { record ->
                                    lastCompletedInvoice = record
                                }
                            },
                            onShareLastInvoice = { inv ->
                                shareTextReport(
                                    context = context,
                                    subject = "Invoice ${inv.invoiceNumber}",
                                    body = "StoreFlow Receipt ${inv.invoiceNumber}\nCustomer: ${inv.customerName}\nItems: ${inv.itemsSummary}\nTotal Paid: ${formatInr(inv.totalAmount)} (${inv.paymentMethod})"
                                )
                            }
                        )
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(salesHistory, key = { it.id }) { sale ->
                            SaleInvoiceRowCard(
                                sale = sale,
                                onShareInvoice = {
                                    shareTextReport(
                                        context = context,
                                        subject = "Invoice ${sale.invoiceNumber}",
                                        body = "StoreFlow Receipt ${sale.invoiceNumber}\nCustomer: ${sale.customerName}\nItems: ${sale.itemsSummary}\nTotal Paid: ${formatInr(sale.totalAmount)} (${sale.paymentMethod})"
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PosCatalogItemCard(
    product: ProductEntity,
    qtyInCart: Int,
    onAdd: () -> Unit,
    onDecrement: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = !product.isOutOfStock, onClick = onAdd)
            .testTag("pos_product_${product.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (qtyInCart > 0) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = product.sku,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "• ${product.stockQty} ${product.unit} available",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (product.isLowStock || product.isOutOfStock) StatusCriticalRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${formatInr(product.sellingPrice)} / ${product.unit}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (qtyInCart == 0) {
                FilledTonalButton(
                    onClick = onAdd,
                    enabled = !product.isOutOfStock,
                    modifier = Modifier.testTag("pos_add_btn_${product.id}")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (product.isOutOfStock) "No Stock" else "Add")
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = onDecrement,
                        modifier = Modifier
                            .size(34.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease quantity", modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = qtyInCart.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = onAdd,
                        modifier = Modifier
                            .size(34.dp)
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "Increase quantity",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PosCheckoutPanel(
    cartItems: List<CartItem>,
    lastInvoice: SaleRecordEntity?,
    onUpdateCartQty: (Long, Int) -> Unit,
    onClearCart: () -> Unit,
    onCheckout: (String, String, String, Double) -> Unit,
    onShareLastInvoice: (SaleRecordEntity) -> Unit
) {
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("UPI") }
    var discountInput by remember { mutableStateOf("0") }

    val grossSubtotal = cartItems.sumOf { it.lineTotal }
    val discountVal = (discountInput.toDoubleOrNull() ?: 0.0).coerceIn(0.0, grossSubtotal)
    val payableTotal = (grossSubtotal - discountVal).coerceAtLeast(0.0)
    val estimatedProfit = (cartItems.sumOf { it.lineProfit } - discountVal).coerceAtLeast(0.0)

    Card(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PointOfSale,
                        contentDescription = "POS Counter",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Live POS Billing Counter",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (cartItems.isNotEmpty()) {
                    IconButton(onClick = onClearCart) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear Cart",
                            tint = StatusCriticalRed
                        )
                    }
                }
            }

            if (lastInvoice != null && cartItems.isEmpty()) {
                Surface(
                    color = StatusHealthyGreen.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = "Completed",
                                    tint = StatusHealthyGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Last Bill: ${lastInvoice.invoiceNumber} (${formatInr(lastInvoice.totalAmount)})",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = StatusHealthyGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Stock automatically deducted in offline SQLite DB.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(onClick = { onShareLastInvoice(lastInvoice) }) {
                            Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Receipt")
                        }
                    }
                }
            }

            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = "Empty Cart",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "Cart is empty",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Tap any item in the POS Catalog to generate an instant customer invoice.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                cartItems.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.product.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${formatInr(item.product.sellingPrice)} x ${item.quantity} = ${formatInr(item.lineTotal)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IconButton(
                                onClick = { onUpdateCartQty(item.product.id, item.quantity - 1) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Minus", modifier = Modifier.size(16.dp))
                            }
                            Text(
                                text = "${item.quantity}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = { onUpdateCartQty(item.product.id, item.quantity + 1) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Plus", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                HorizontalDivider()

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Customer Name (Optional)") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("pos_customer_name_input")
                    )
                    OutlinedTextField(
                        value = discountInput,
                        onValueChange = { discountInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Discount (${activeCurrencySymbol.trim()})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.width(120.dp)
                    )
                }

                OutlinedTextField(
                    value = customerPhone,
                    onValueChange = { customerPhone = it.filter { ch -> ch.isDigit() || ch == '+' } },
                    label = { Text("Customer Mobile (for WhatsApp / SMS Bill)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Payment Mode",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PAYMENT_MODES.forEach { mode ->
                        FilterChip(
                            selected = paymentMethod == mode,
                            onClick = { paymentMethod = mode },
                            label = { Text(mode) },
                            modifier = Modifier.testTag("payment_mode_${mode.lowercase().substringBefore(" ")}")
                        )
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Subtotal (${cartItems.sumOf { it.quantity }} units)", style = MaterialTheme.typography.bodySmall)
                            Text(formatInr(grossSubtotal), style = MaterialTheme.typography.bodySmall)
                        }
                        if (discountVal > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Discount", style = MaterialTheme.typography.bodySmall, color = StatusCriticalRed)
                                Text("-${formatInr(discountVal)}", style = MaterialTheme.typography.bodySmall, color = StatusCriticalRed)
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Net Payable ($paymentMethod)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = formatInr(payableTotal),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            text = "Estimated Margin on Bill: +${formatInr(estimatedProfit)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusHealthyGreen
                        )
                    }
                }

                Button(
                    onClick = {
                        onCheckout(customerName, customerPhone, paymentMethod, discountVal)
                        customerName = ""
                        customerPhone = ""
                        discountInput = "0"
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("complete_sale_checkout_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.ShoppingCartCheckout, contentDescription = "Complete Sale")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Complete Sale • ${formatInr(payableTotal)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
