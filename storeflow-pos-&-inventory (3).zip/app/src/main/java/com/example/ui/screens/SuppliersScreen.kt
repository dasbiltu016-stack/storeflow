package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ProductEntity
import com.example.data.local.PurchaseOrderEntity
import com.example.data.local.SupplierEntity
import com.example.ui.components.activeCurrencySymbol
import com.example.ui.components.formatInr
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.StatusCriticalRed
import com.example.ui.theme.StatusHealthyGreen
import com.example.ui.theme.StatusWarningAmber

@Composable
fun SuppliersScreen(
    isExpandedTablet: Boolean,
    suppliers: List<SupplierEntity>,
    products: List<ProductEntity>,
    purchaseOrders: List<PurchaseOrderEntity>,
    supplierSearchQuery: String,
    selectedSupplierId: Long?,
    onSearchQueryChange: (String) -> Unit,
    onSelectSupplier: (Long?) -> Unit,
    onSaveSupplier: (SupplierEntity) -> Unit,
    onDeleteSupplier: (SupplierEntity) -> Unit,
    onCreatePurchaseOrder: (SupplierEntity, ProductEntity, Int, Double) -> Unit,
    onReceivePurchaseOrder: (PurchaseOrderEntity) -> Unit
) {
    var showAddOrEditSupplierDialog by remember { mutableStateOf(false) }
    var editingSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var showCreatePoDialog by remember { mutableStateOf(false) }
    var showMobileSupplierDetail by remember { mutableStateOf(false) }

    val filteredSuppliers = remember(suppliers, supplierSearchQuery) {
        suppliers.filter { sup ->
            supplierSearchQuery.isBlank() ||
                sup.name.contains(supplierSearchQuery, ignoreCase = true) ||
                sup.contactPerson.contains(supplierSearchQuery, ignoreCase = true) ||
                sup.category.contains(supplierSearchQuery, ignoreCase = true) ||
                sup.city.contains(supplierSearchQuery, ignoreCase = true)
        }
    }

    val activeSupplier = remember(suppliers, selectedSupplierId) {
        suppliers.find { it.id == selectedSupplierId } ?: suppliers.firstOrNull()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = supplierSearchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search suppliers, city, or category…") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Suppliers") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("supplier_search_input")
                )

                Button(
                    onClick = {
                        editingSupplier = null
                        showAddOrEditSupplierDialog = true
                    },
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    modifier = Modifier.testTag("add_supplier_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Supplier")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Vendor", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (isExpandedTablet) {
            // Canonical Tablet Split-Pane Supplier Directory & Purchase Order Hub
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .weight(1.05f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredSuppliers, key = { it.id }) { supplier ->
                        val suppliedCount = products.count { it.supplierId == supplier.id }
                        val pendingCount = purchaseOrders.count { it.supplierId == supplier.id && it.status == "PENDING" }
                        SupplierCard(
                            supplier = supplier,
                            suppliedProductsCount = suppliedCount,
                            pendingPoCount = pendingCount,
                            isSelected = activeSupplier?.id == supplier.id,
                            onClick = { onSelectSupplier(supplier.id) },
                            onCreateRestockOrder = {
                                onSelectSupplier(supplier.id)
                                showCreatePoDialog = true
                            }
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(0.95f)
                        .fillMaxHeight()
                ) {
                    if (activeSupplier != null) {
                        SupplierDetailAndOrdersPanel(
                            supplier = activeSupplier,
                            suppliedProducts = products.filter { it.supplierId == activeSupplier.id },
                            supplierOrders = purchaseOrders.filter { it.supplierId == activeSupplier.id },
                            onEditSupplier = {
                                editingSupplier = activeSupplier
                                showAddOrEditSupplierDialog = true
                            },
                            onDeleteSupplier = { onDeleteSupplier(activeSupplier) },
                            onCreateRestockOrder = { showCreatePoDialog = true },
                            onReceiveOrder = onReceivePurchaseOrder
                        )
                    }
                }
            }
        } else {
            // Mobile Single-Column Supplier Directory + Pending PO Queue
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val pendingOrders = purchaseOrders.filter { it.status == "PENDING" }
                if (pendingOrders.isNotEmpty()) {
                    item {
                        Text(
                            text = "Pending Restock Purchase Orders (${pendingOrders.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(pendingOrders, key = { "po_${it.id}" }) { po ->
                        PurchaseOrderRowCard(
                            order = po,
                            onReceiveOrder = { onReceivePurchaseOrder(po) }
                        )
                    }
                }

                item {
                    Text(
                        text = "Wholesale Suppliers (${filteredSuppliers.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(filteredSuppliers, key = { it.id }) { supplier ->
                    val suppliedCount = products.count { it.supplierId == supplier.id }
                    val pendingCount = purchaseOrders.count { it.supplierId == supplier.id && it.status == "PENDING" }
                    SupplierCard(
                        supplier = supplier,
                        suppliedProductsCount = suppliedCount,
                        pendingPoCount = pendingCount,
                        isSelected = false,
                        onClick = {
                            onSelectSupplier(supplier.id)
                            showMobileSupplierDetail = true
                        },
                        onCreateRestockOrder = {
                            onSelectSupplier(supplier.id)
                            showCreatePoDialog = true
                        }
                    )
                }
            }
        }
    }

    if (!isExpandedTablet && showMobileSupplierDetail && activeSupplier != null) {
        AlertDialog(
            onDismissRequest = { showMobileSupplierDetail = false },
            text = {
                SupplierDetailAndOrdersPanel(
                    supplier = activeSupplier,
                    suppliedProducts = products.filter { it.supplierId == activeSupplier.id },
                    supplierOrders = purchaseOrders.filter { it.supplierId == activeSupplier.id },
                    onEditSupplier = {
                        showMobileSupplierDetail = false
                        editingSupplier = activeSupplier
                        showAddOrEditSupplierDialog = true
                    },
                    onDeleteSupplier = {
                        showMobileSupplierDetail = false
                        onDeleteSupplier(activeSupplier)
                    },
                    onCreateRestockOrder = {
                        showMobileSupplierDetail = false
                        showCreatePoDialog = true
                    },
                    onReceiveOrder = onReceivePurchaseOrder
                )
            },
            confirmButton = {
                TextButton(onClick = { showMobileSupplierDetail = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showAddOrEditSupplierDialog) {
        AddOrEditSupplierDialog(
            initialSupplier = editingSupplier,
            onDismiss = { showAddOrEditSupplierDialog = false },
            onConfirm = { saved ->
                onSaveSupplier(saved)
                showAddOrEditSupplierDialog = false
            }
        )
    }

    if (showCreatePoDialog && activeSupplier != null) {
        CreatePurchaseOrderDialog(
            supplier = activeSupplier,
            products = products,
            onDismiss = { showCreatePoDialog = false },
            onConfirm = { prod, qty, unitCost ->
                onCreatePurchaseOrder(activeSupplier, prod, qty, unitCost)
                showCreatePoDialog = false
            }
        )
    }
}

@Composable
private fun SupplierCard(
    supplier: SupplierEntity,
    suppliedProductsCount: Int,
    pendingPoCount: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    onCreateRestockOrder: () -> Unit
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("supplier_card_${supplier.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = supplier.category,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = "• ${supplier.city} • ${supplier.leadTimeDays}d delivery",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = supplier.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Contact: ${supplier.contactPerson} (${supplier.phone})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Rating",
                        tint = AmberAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = supplier.rating.toString(),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$suppliedProductsCount products • $pendingPoCount pending PO",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = {
                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${supplier.phone}"))
                            context.startActivity(dialIntent)
                        },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Call Supplier",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    FilledTonalButton(
                        onClick = onCreateRestockOrder,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("create_po_btn_${supplier.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalShipping,
                            contentDescription = "New Restock PO",
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Order Stock", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun SupplierDetailAndOrdersPanel(
    supplier: SupplierEntity,
    suppliedProducts: List<ProductEntity>,
    supplierOrders: List<PurchaseOrderEntity>,
    onEditSupplier: () -> Unit,
    onDeleteSupplier: () -> Unit,
    onCreateRestockOrder: () -> Unit,
    onReceiveOrder: (PurchaseOrderEntity) -> Unit
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${supplier.category} • ${supplier.city}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = supplier.name,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Representative: ${supplier.contactPerson}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row {
                    IconButton(onClick = onEditSupplier) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Supplier")
                    }
                    IconButton(onClick = onDeleteSupplier) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Delete Supplier",
                            tint = StatusCriticalRed
                        )
                    }
                }
            }

            if (supplier.notes.isNotBlank()) {
                Text(
                    text = supplier.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${supplier.phone}")))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call")
                }
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${supplier.email}")))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Email, contentDescription = "Email", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Email")
                }
                Button(
                    onClick = onCreateRestockOrder,
                    modifier = Modifier.weight(1.3f)
                ) {
                    Icon(Icons.Default.LocalShipping, contentDescription = "Order", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New PO")
                }
            }

            HorizontalDivider()

            Text(
                text = "Purchase Orders (${supplierOrders.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            if (supplierOrders.isEmpty()) {
                Text(
                    text = "No purchase orders created for this vendor yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                supplierOrders.forEach { order ->
                    PurchaseOrderRowCard(
                        order = order,
                        onReceiveOrder = { onReceiveOrder(order) }
                    )
                }
            }

            HorizontalDivider()

            Text(
                text = "Catalog Items Linked (${suppliedProducts.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            suppliedProducts.forEach { prod ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = prod.name,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Cost: ${formatInr(prod.costPrice)} • On-hand: ${prod.stockQty} ${prod.unit}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PurchaseOrderRowCard(
    order: PurchaseOrderEntity,
    onReceiveOrder: () -> Unit
) {
    val isPending = order.status == "PENDING"
    Surface(
        color = if (isPending) {
            StatusWarningAmber.copy(alpha = 0.1f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        },
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = order.poNumber,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "• ${order.supplierName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "${order.productName} (+${order.quantity} units)",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Total Order Cost: ${formatInr(order.totalCost)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (isPending) {
                Button(
                    onClick = onReceiveOrder,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("receive_po_${order.id}")
                ) {
                    Text("Receive +${order.quantity}", style = MaterialTheme.typography.labelMedium)
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Received",
                        tint = StatusHealthyGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Received",
                        style = MaterialTheme.typography.labelMedium,
                        color = StatusHealthyGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun AddOrEditSupplierDialog(
    initialSupplier: SupplierEntity?,
    onDismiss: () -> Unit,
    onConfirm: (SupplierEntity) -> Unit
) {
    var name by remember { mutableStateOf(initialSupplier?.name ?: "") }
    var contactPerson by remember { mutableStateOf(initialSupplier?.contactPerson ?: "") }
    var phone by remember { mutableStateOf(initialSupplier?.phone ?: "+91 ") }
    var email by remember { mutableStateOf(initialSupplier?.email ?: "") }
    var category by remember { mutableStateOf(initialSupplier?.category ?: "") }
    var city by remember { mutableStateOf(initialSupplier?.city ?: "") }
    var leadTime by remember { mutableStateOf(initialSupplier?.leadTimeDays?.toString() ?: "2") }
    var notes by remember { mutableStateOf(initialSupplier?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initialSupplier == null) "Add Wholesale Supplier" else "Edit Supplier")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Company / Agency Name *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_supplier_name_input")
                )
                OutlinedTextField(
                    value = contactPerson,
                    onValueChange = { contactPerson = it },
                    label = { Text("Contact Person") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("City / Area") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category (Manual)") },
                        placeholder = { Text("Type any category…") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = leadTime,
                        onValueChange = { leadTime = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Lead Days") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.7f)
                    )
                }
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Supply Notes / Payment Terms") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(
                            SupplierEntity(
                                id = initialSupplier?.id ?: 0L,
                                name = name.trim(),
                                contactPerson = contactPerson.ifBlank { "Store Manager" },
                                phone = phone.trim(),
                                email = email.trim(),
                                category = category.ifBlank { "General" },
                                leadTimeDays = leadTime.toIntOrNull() ?: 2,
                                rating = initialSupplier?.rating ?: 4.7f,
                                city = city.ifBlank { "India" },
                                notes = notes.trim()
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("save_supplier_confirm_button")
            ) {
                Text("Save Supplier")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun CreatePurchaseOrderDialog(
    supplier: SupplierEntity,
    products: List<ProductEntity>,
    onDismiss: () -> Unit,
    onConfirm: (ProductEntity, Int, Double) -> Unit
) {
    val supplierProducts = remember(products, supplier.id) {
        val linked = products.filter { it.supplierId == supplier.id }
        linked.ifEmpty { products }
    }
    var selectedProduct by remember { mutableStateOf(supplierProducts.firstOrNull()) }
    var qtyInput by remember { mutableStateOf("20") }
    var unitCostInput by remember(selectedProduct) {
        mutableStateOf(selectedProduct?.costPrice?.toInt()?.toString() ?: "150")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Create Restock PO • ${supplier.name}")
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Select Product to Restock:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    supplierProducts.forEach { prod ->
                        FilterChip(
                            selected = selectedProduct?.id == prod.id,
                            onClick = {
                                selectedProduct = prod
                                unitCostInput = prod.costPrice.toInt().toString()
                            },
                            label = { Text(prod.name) }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyInput,
                        onValueChange = { qtyInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Order Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unitCostInput,
                        onValueChange = { unitCostInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Unit Cost (${activeCurrencySymbol.trim()})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                val total = (qtyInput.toIntOrNull() ?: 0) * (unitCostInput.toDoubleOrNull() ?: 0.0)
                Text(
                    text = "Total Purchase Order Cost: ${formatInr(total)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val prod = selectedProduct
                    val qty = qtyInput.toIntOrNull() ?: 0
                    val cost = unitCostInput.toDoubleOrNull() ?: 0.0
                    if (prod != null && qty > 0) {
                        onConfirm(prod, qty, cost)
                    }
                },
                modifier = Modifier.testTag("confirm_create_po_button")
            ) {
                Text("Place Restock Order")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
