package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF4F46E5)
val EmeraldSecondary = Color(0xFF7C3AED)
val AmberAccent = Color(0xFFEA580C)
val AmberHighlight = Color(0xFFF59E0B)

val WarmBackgroundLight = Color(0xFFF4F2FF)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDE9FE)
val OnSurfaceLight = Color(0xFF111827)
val OnSurfaceVariantLight = Color(0xFF312E81)

val EmeraldPrimaryDark = Color(0xFF4F46E5)
val EmeraldSecondaryDark = Color(0xFF7C3AED)
val AmberAccentDark = Color(0xFFEA580C)

val BackgroundDark = Color(0xFFF4F2FF)
val SurfaceDark = Color(0xFFFFFFFF)
val SurfaceVariantDark = Color(0xFFEDE9FE)
val OnSurfaceDark = Color(0xFF111827)
val OnSurfaceVariantDark = Color(0xFF312E81)

val StatusHealthyGreen = Color(0xFF059669)
val StatusWarningAmber = Color(0xFFD97706)
val StatusCriticalRed = Color(0xFFDC2626)
val StatusInfoBlue = Color(0xFF2563EB)
