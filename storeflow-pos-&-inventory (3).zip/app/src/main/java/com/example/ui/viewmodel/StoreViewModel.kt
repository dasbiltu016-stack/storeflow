package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CustomerDueEntity
import com.example.data.local.DueTransactionEntity
import com.example.data.local.ProductEntity
import com.example.data.local.PurchaseOrderEntity
import com.example.data.local.SaleRecordEntity
import com.example.data.local.StockMovementEntity
import com.example.data.local.StoreDatabase
import com.example.data.local.StoreSettingsEntity
import com.example.data.local.SupplierEntity
import com.example.data.repository.CartItem
import com.example.data.repository.StoreRepository
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class StoreSection {
    DASHBOARD,
    INVENTORY,
    POS_SALES,
    CUSTOMER_DUES,
    SUPPLIERS
}

enum class StockFilter {
    ALL,
    LOW_STOCK,
    OUT_OF_STOCK
}

enum class ReportPeriod(val label: String) {
    ALL_TIME("All Time"),
    LAST_7_DAYS("Last 7 Days"),
    TODAY("Today")
}

data class DailyChartPoint(
    val dayLabel: String,
    val revenue: Double,
    val profit: Double
)

data class CategorySalesSlice(
    val category: String,
    val revenue: Double,
    val percentage: Float
)

data class StoreUiPreferences(
    val currentSection: StoreSection = StoreSection.DASHBOARD,
    val searchQuery: String = "",
    val selectedCategory: String = "All",
    val stockFilter: StockFilter = StockFilter.ALL,
    val reportPeriod: ReportPeriod = ReportPeriod.ALL_TIME,
    val supplierSearchQuery: String = "",
    val customerSearchQuery: String = "",
    val showOnlyPendingDues: Boolean = false,
    val selectedProductId: Long? = 1L,
    val selectedSupplierId: Long? = 1L,
    val selectedCustomerId: Long? = 1L,
    val strictOfflineMode: Boolean = true,
    val autoLocalSnapshot: Boolean = true,
    val lastSavedTimestamp: Long = System.currentTimeMillis(),
    val statusBannerMessage: String? = null
)

class StoreViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: StoreRepository = StoreRepository(
        StoreDatabase.getInstance(application).storeDao()
    )

    val products: StateFlow<List<ProductEntity>> = repository.allProducts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val suppliers: StateFlow<List<SupplierEntity>> = repository.allSuppliers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val sales: StateFlow<List<SaleRecordEntity>> = repository.allSales.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val stockMovements: StateFlow<List<StockMovementEntity>> = repository.recentMovements.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val purchaseOrders: StateFlow<List<PurchaseOrderEntity>> = repository.allPurchaseOrders.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val customerDues: StateFlow<List<CustomerDueEntity>> = repository.allCustomerDues.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val dueTransactions: StateFlow<List<DueTransactionEntity>> = repository.allDueTransactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val storeSettings: StateFlow<StoreSettingsEntity> = repository.storeSettings
        .map { it ?: StoreSettingsEntity() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = StoreSettingsEntity()
        )

    private val _prefs = MutableStateFlow(StoreUiPreferences())
    val prefs: StateFlow<StoreUiPreferences> = _prefs.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureSeedDataLoaded()
        }
    }

    fun selectSection(section: StoreSection) {
        _prefs.update { it.copy(currentSection = section) }
    }

    fun updateSearchQuery(query: String) {
        _prefs.update { it.copy(searchQuery = query) }
    }

    fun updateSelectedCategory(category: String) {
        _prefs.update { it.copy(selectedCategory = category) }
    }

    fun updateStockFilter(filter: StockFilter) {
        _prefs.update { it.copy(stockFilter = filter) }
    }

    fun updateReportPeriod(period: ReportPeriod) {
        _prefs.update { it.copy(reportPeriod = period) }
    }

    fun updateSupplierSearch(query: String) {
        _prefs.update { it.copy(supplierSearchQuery = query) }
    }

    fun updateCustomerSearch(query: String) {
        _prefs.update { it.copy(customerSearchQuery = query) }
    }

    fun toggleShowOnlyPendingDues(onlyPending: Boolean) {
        _prefs.update { it.copy(showOnlyPendingDues = onlyPending) }
    }

    fun selectProduct(productId: Long?) {
        _prefs.update { it.copy(selectedProductId = productId) }
    }

    fun selectSupplier(supplierId: Long?) {
        _prefs.update { it.copy(selectedSupplierId = supplierId) }
    }

    fun selectCustomer(customerId: Long?) {
        _prefs.update { it.copy(selectedCustomerId = customerId) }
    }

    fun toggleStrictOfflineMode(enabled: Boolean) {
        _prefs.update {
            it.copy(
                strictOfflineMode = enabled,
                lastSavedTimestamp = System.currentTimeMillis(),
                statusBannerMessage = if (enabled) {
                    "Strict Offline Mode enabled: All data stored locally in Room SQLite."
                } else {
                    "Standard Local Mode active: Ready for export & sharing."
                }
            )
        }
    }

    fun toggleAutoLocalSnapshot(enabled: Boolean) {
        _prefs.update {
            it.copy(
                autoLocalSnapshot = enabled,
                lastSavedTimestamp = System.currentTimeMillis()
            )
        }
    }

    fun clearBannerMessage() {
        _prefs.update { it.copy(statusBannerMessage = null) }
    }

    // --- Store Settings Actions ---
    fun saveStoreSettings(settings: StoreSettingsEntity) {
        viewModelScope.launch {
            repository.saveStoreSettings(settings)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Store Settings updated for '${settings.storeName}'."
                )
            }
        }
    }

    // --- Inventory Actions ---
    fun saveProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.saveProduct(product)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Saved '${product.name}' to offline inventory."
                )
            }
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Removed '${product.name}' from inventory."
                )
            }
        }
    }

    fun adjustStock(product: ProductEntity, delta: Int, reason: String) {
        if (delta == 0) return
        viewModelScope.launch {
            val type = if (delta > 0) "RESTOCK" else "MANUAL_ADJUST"
            repository.adjustStock(product.id, delta, type, reason)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Updated ${product.name} stock (${if (delta > 0) "+$delta" else "$delta"})."
                )
            }
        }
    }

    // --- POS Cart & Checkout Actions ---
    fun addToCart(product: ProductEntity) {
        if (product.stockQty <= 0) {
            _prefs.update {
                it.copy(statusBannerMessage = "'${product.name}' is out of stock! Restock first.")
            }
            return
        }
        _cart.update { current ->
            val existing = current.find { it.product.id == product.id }
            if (existing != null) {
                if (existing.quantity >= product.stockQty) {
                    current
                } else {
                    current.map {
                        if (it.product.id == product.id) it.copy(quantity = it.quantity + 1) else it
                    }
                }
            } else {
                current + CartItem(product = product, quantity = 1)
            }
        }
    }

    fun updateCartItemQuantity(productId: Long, newQuantity: Int) {
        _cart.update { current ->
            if (newQuantity <= 0) {
                current.filterNot { it.product.id == productId }
            } else {
                current.map { item ->
                    if (item.product.id == productId) {
                        val capped = newQuantity.coerceAtMost(item.product.stockQty.coerceAtLeast(1))
                        item.copy(quantity = capped)
                    } else {
                        item
                    }
                }
            }
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun completeSaleCheckout(
        customerName: String,
        customerPhone: String,
        paymentMethod: String,
        discountAmount: Double,
        onComplete: (SaleRecordEntity) -> Unit = {}
    ) {
        val currentCart = _cart.value
        if (currentCart.isEmpty()) return
        viewModelScope.launch {
            val record = repository.recordSaleCheckout(
                cartItems = currentCart,
                customerName = customerName,
                customerPhone = customerPhone,
                paymentMethod = paymentMethod,
                discountAmount = discountAmount
            )
            _cart.value = emptyList()
            if (record != null) {
                val sym = storeSettings.value.currencySymbol
                val extraMsg = if (paymentMethod == "Due / Credit") " & added to Customer Due!" else "."
                _prefs.update {
                    it.copy(
                        lastSavedTimestamp = System.currentTimeMillis(),
                        statusBannerMessage = "Invoice ${record.invoiceNumber} saved ($sym${record.totalAmount.toInt()})$extraMsg"
                    )
                }
                onComplete(record)
            }
        }
    }

    // --- Customer Due Actions ---
    fun saveCustomerDue(customer: CustomerDueEntity) {
        viewModelScope.launch {
            repository.saveCustomerDue(customer)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Customer Due saved for '${customer.customerName}'."
                )
            }
        }
    }

    fun addCustomerCredit(customer: CustomerDueEntity, amount: Double, note: String) {
        viewModelScope.launch {
            val sym = storeSettings.value.currencySymbol
            repository.addCustomerCredit(customer.id, amount, note)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Added $sym${amount.toInt()} credit due to ${customer.customerName}."
                )
            }
        }
    }

    fun recordCustomerDuePayment(
        customer: CustomerDueEntity,
        amount: Double,
        paymentMode: String,
        note: String
    ) {
        viewModelScope.launch {
            val sym = storeSettings.value.currencySymbol
            repository.recordCustomerDuePayment(customer.id, amount, paymentMode, note)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Received $sym${amount.toInt()} ($paymentMode) from ${customer.customerName}!"
                )
            }
        }
    }

    fun deleteCustomerDue(customer: CustomerDueEntity) {
        viewModelScope.launch {
            repository.deleteCustomerDue(customer)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Removed customer account '${customer.customerName}'."
                )
            }
        }
    }

    // --- Supplier & PO Actions ---
    fun saveSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            repository.saveSupplier(supplier)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Supplier '${supplier.name}' saved."
                )
            }
        }
    }

    fun deleteSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            repository.deleteSupplier(supplier)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Deleted supplier '${supplier.name}'."
                )
            }
        }
    }

    fun createPurchaseOrder(
        supplier: SupplierEntity,
        product: ProductEntity,
        quantity: Int,
        unitCost: Double
    ) {
        viewModelScope.launch {
            repository.createPurchaseOrder(supplier, product, quantity, unitCost)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Purchase Order created for ${quantity}x ${product.name}."
                )
            }
        }
    }

    fun receivePurchaseOrder(order: PurchaseOrderEntity) {
        viewModelScope.launch {
            repository.receivePurchaseOrder(order)
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Received ${order.poNumber}: +${order.quantity} added to ${order.productName}!"
                )
            }
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetAndSeedSampleData()
            _cart.value = emptyList()
            _prefs.update {
                it.copy(
                    lastSavedTimestamp = System.currentTimeMillis(),
                    statusBannerMessage = "Sample store inventory, sales, customer dues & suppliers restored!"
                )
            }
        }
    }

    // --- Analytics & Export Helpers ---
    fun buildLast7DaysChart(allSales: List<SaleRecordEntity>): List<DailyChartPoint> {
        val fmt = SimpleDateFormat("EEE", Locale.US)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        val todayStart = cal.timeInMillis
        val dayMs = 86_400_000L

        return (6 downTo 0).map { daysAgo ->
            val start = todayStart - (daysAgo * dayMs)
            val end = start + dayMs
            val daySales = allSales.filter { it.timestamp in start until end }
            DailyChartPoint(
                dayLabel = if (daysAgo == 0) "Today" else fmt.format(Date(start)),
                revenue = daySales.sumOf { it.totalAmount },
                profit = daySales.sumOf { it.totalProfit }
            )
        }
    }

    fun buildCategoryBreakdown(filteredSales: List<SaleRecordEntity>): List<CategorySalesSlice> {
        val totalRev = filteredSales.sumOf { it.totalAmount }.coerceAtLeast(1.0)
        return filteredSales
            .groupBy { it.primaryCategory }
            .map { (cat, list) ->
                val sum = list.sumOf { it.totalAmount }
                CategorySalesSlice(
                    category = cat,
                    revenue = sum,
                    percentage = ((sum / totalRev) * 100.0).toFloat()
                )
            }
            .sortedByDescending { it.revenue }
    }

    fun generateCsvSalesAndInventoryReport(
        productsList: List<ProductEntity>,
        salesList: List<SaleRecordEntity>,
        suppliersList: List<SupplierEntity>,
        customerDuesList: List<CustomerDueEntity> = emptyList(),
        settings: StoreSettingsEntity = StoreSettingsEntity()
    ): String {
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val sb = StringBuilder()
        val curCode = settings.currencyCode.ifBlank { "INR" }
        sb.appendLine("=== ${settings.storeName.uppercase()} - OFFLINE BUSINESS REPORT ($dateStr) ===")
        sb.appendLine("Owner: ${settings.ownerName} | Phone: ${settings.storePhone} | Currency: ${settings.currencySymbol.trim()} ($curCode) | Tax/Reg: ${settings.gstNumber}")
        sb.appendLine()
        sb.appendLine("--- 1. SALES SUMMARY ---")
        sb.appendLine("Total Invoices,${salesList.size}")
        sb.appendLine("Total Revenue ($curCode),${salesList.sumOf { it.totalAmount }.toInt()}")
        sb.appendLine("Total Net Profit ($curCode),${salesList.sumOf { it.totalProfit }.toInt()}")
        sb.appendLine()
        sb.appendLine("Invoice,Customer,Payment,Category,Items,Amount ($curCode),Profit ($curCode)")
        salesList.forEach { s ->
            sb.appendLine("${s.invoiceNumber},\"${s.customerName}\",${s.paymentMethod},${s.primaryCategory},\"${s.itemsSummary}\",${s.totalAmount.toInt()},${s.totalProfit.toInt()}")
        }
        sb.appendLine()
        sb.appendLine("--- 2. CUSTOMER DUES (${customerDuesList.size} Accounts) ---")
        sb.appendLine("Total Pending Market Due ($curCode),${customerDuesList.sumOf { it.dueBalance }.toInt()}")
        sb.appendLine("Customer Name,Phone,Total Credit,Total Paid,Pending Due Balance ($curCode),Last Note")
        customerDuesList.forEach { c ->
            sb.appendLine("\"${c.customerName}\",${c.phone},${c.totalCreditGiven.toInt()},${c.totalPaidAmount.toInt()},${c.dueBalance.toInt()},\"${c.lastTransactionNote}\"")
        }
        sb.appendLine()
        sb.appendLine("--- 3. INVENTORY STATUS (${productsList.size} SKUs) ---")
        sb.appendLine("SKU,Product Name,Category,Stock Qty,Min Level,Cost Price,Selling Price,Supplier")
        productsList.forEach { p ->
            sb.appendLine("${p.sku},\"${p.name}\",${p.category},${p.stockQty},${p.minStockLevel},${p.costPrice.toInt()},${p.sellingPrice.toInt()},\"${p.supplierName}\"")
        }
        sb.appendLine()
        sb.appendLine("--- 4. SUPPLIERS (${suppliersList.size}) ---")
        sb.appendLine("Supplier Name,Contact Person,Phone,Category,Lead Time (Days)")
        suppliersList.forEach { sup ->
            sb.appendLine("\"${sup.name}\",\"${sup.contactPerson}\",${sup.phone},${sup.category},${sup.leadTimeDays}")
        }
        return sb.toString()
    }
}
